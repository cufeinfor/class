# !/usr/bin/env python
# -*- coding: UTF-8 -*-
'''
@Project ：ActiveLearningForHumanValue 
@File ：multi_laber_classifier.py
@IDE  ：PyCharm 
@Author ：AmandaQiao
@Date ：2022/9/26 13:34 
@Description:
'''
from torch import nn
from transformers import AutoModel

#首先利用 Transformers 库加载 BERT 模型，然后接一个全连接层完成分类：
#定义下游任务模型，不同模型不同定义服务不同下游任务，主要修改这个类
class classifer_model(nn.Module):#继承bert
    def __init__(self):
        super(classifer_model, self).__init__()#继承bert
        #加载预训练模型，使用它，这一句是获得预训练模型最后一层的结果768维的encoder
        # super().__init__()
        self.bert_encoder = AutoModel.from_pretrained(f'D:/PycharmWorkspace/ActiveLearningForHumanValue/bert/bert-base-uncased')
        self.dropout = nn.Dropout(0.1)#一般加个dropout避免过拟合
        self.classifier = nn.Linear(768, 10)#分类层，11个类别,saner用10个类别

    def forward(self, x):
        #将X输入到bert的encoder，获得bert预训练模型最后一层的encode结果，等于是抽取到的特征
        bert_output = self.bert_encoder(**x) #取上述最后一层结果的第一位[:, 0]作为整个句子的向量，因为是拿到整句话的一个语义
        cls_vectors = bert_output.last_hidden_state[:, 0]
        cls_vectors = self.dropout(cls_vectors)
        logits = self.classifier(cls_vectors)#将句子向量输入到分类层，得到logits值，#logits加sigmod或者soft就是pred了
        # probs = logits.sigmoid()
        return logits






