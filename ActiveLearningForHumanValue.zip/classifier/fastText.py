# !/usr/bin/env python
# -*- coding: UTF-8 -*-
'''
@Project ：ActiveLearningForHumanValue 
@File ：fastText.py
@IDE  ：PyCharm 
@Author ：AmandaQiao
@Date ：2023/3/25 21:55 
@Description:
'''
import csv

from sklearn.metrics import classification_report,coverage_error,label_ranking_average_precision_score,label_ranking_loss
import numpy as np
import pandas as pd
from sklearn.preprocessing import StandardScaler
from sklearn.feature_extraction.text import TfidfVectorizer
import fasttext#
from sklearn.model_selection import train_test_split


def getDatatxt(datapath):
    # 转换数据形式用的代码

    with open(datapath, 'r', encoding='utf-8') as f:
        reader = csv.reader(f)
        next(reader)# 跳过表头
        with open('data.txt', 'w', encoding='utf-8') as f_out:
            for row in reader:
                text = row[1]  # 第1列为文本
                labels = ' '.join([f'__label__{i}' for i, label in enumerate(row[2:13], start=1) if label == '1'])
                # 第2列到第6列为类别标签，转换为FastText需要的格式
                f_out.write(f'{labels} {text}\n')

    with open('data.txt', 'r', encoding='utf-8') as f:
        data = f.readlines()

    train_data, test_data = train_test_split(data, test_size=0.2)
    with open('train.txt', 'w', encoding='utf-8') as f:
        f.writelines(train_data)

    with open('test.txt', 'w', encoding='utf-8') as f:
        f.writelines(test_data)


if __name__ == '__main__':
    datapath = '../jy/summary_valueSentiment.csv'
    # getDatatxt(datapath) # 转换数据为fasttext需要的格式

    # 训练模型
    model = fasttext.train_supervised(input='train.txt', epoch=10, lr=0.1, wordNgrams=2, bucket=200000)

    # 评估模型
    result = model.test('test.txt')
    # 输出整体评估指标,好像没有其他指标可以输出来
    print('Precision@1:', result[1])
    print('Recall@1:', result[2])
    print('Number of examples:', result[0])


    '''
epoch=25, lr=0.5, wordNgrams=2, bucket=200000,  
Read 0M words
Number of words:  4458
Number of labels: 11
Progress: 100.0% words/sec/thread:  421893 lr:  0.000000 avg.loss:  1.092605 ETA:   0h 0m 0s
Precision@1: 0.8
Recall@1: 0.47648902821316613
Number of examples: 190

    '''