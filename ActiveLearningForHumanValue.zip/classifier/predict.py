# !/usr/bin/env python
# -*- coding: UTF-8 -*-
'''
@Project ：ActiveLearningForHumanValue 
@File ：predict.py
@IDE  ：PyCharm 
@Author ：AmandaQiao
@Date ：2022/9/26 20:35 
@Description:
'''
from classifier.multi_laber_classifier import classifer_model

# classifier = classifer_model()

def predict_proba(model,X):
    logits = model(X)
    probs = logits.sigmoid()
    return probs

