# !/usr/bin/env python
# -*- coding: UTF-8 -*-
'''
@Project ：ActiveLearningForHumanValue 
@File ：query.py
@IDE  ：PyCharm 

@Description:
'''
import warnings

import numpy as np
import torch
# from modAL.models.base import BaseLearner
# from modAL.uncertainty import uncertainty_sampling
# from sklearn.base import BaseEstimator
from sklearn.exceptions import NotFittedError
from scipy.stats import entropy
from modAL.utils.selection import multi_argmax, shuffled_argmax
from classifier.predict import predict_proba
from typing import Callable, Optional, Tuple, List, Any
from tqdm import tqdm



def entropy_sampling(classifier, Dataloader,n_instances: int = 1, random_tie_break: bool = False):
    entropy = classifier_entropy(classifier, Dataloader)
    if not random_tie_break:
        return multi_argmax(entropy, n_instances=n_instances)
    return shuffled_argmax(entropy, n_instances=n_instances)

def classifier_entropy(classifier, Dataloader):
    try:

       # pred = torch.empty(1, 11)  
       pred = torch.empty(1, 10)  
       for X, Y in Dataloader:
           pre = predict_proba(classifier, X)
           pred = torch.cat([pred, pre], 0)  
       predi = pred.detach().numpy().tolist()  
       del predi[0]
       # uncertainty=predi
       entropy_list=entropy(np.transpose(predi))
    except NotFittedError:
        return np.zeros(shape=(len(Dataloader.dataset),))
    return entropy_list


# MaxScore query strategy for multilabel classification.
def max_score_sampling(classifier, Dataloader,n_instances: int = 1, random_tie_break: bool = 1):
    pred = torch.empty(1, 10)  
    # pred = torch.empty(1, 11) 
    for index,X, Y in tqdm(Dataloader):
        with torch.no_grad():
            pre = predict_proba(classifier, X)
            pred = torch.cat([pred, pre], 0)  
    predi = pred.detach().numpy().tolist()  
    del predi[0]  

    classwise_confidence=torch.tensor(predi)
    classwise_predictions = getBinaryTensor(classwise_confidence, 0.5)  
    classwise_scores = classwise_confidence*(classwise_predictions - 1/2)
    classwise_max = np.max(classwise_scores.detach().numpy(), axis=1)

    if not random_tie_break:
        return multi_argmax(classwise_max, n_instances)
    return shuffled_argmax(classwise_max, n_instances)


def min_confidence_sampling(classifier, Dataloader,n_instances: int = 1, random_tie_break: bool = 1):
    pred = torch.empty(1, 10) 
    # pred = torch.empty(1, 11)
    for index,X, Y in tqdm(Dataloader):
        with torch.no_grad():
            pre = predict_proba(classifier, X)
            pred = torch.cat([pred, pre], 0) 
    predi = pred.detach().numpy().tolist()  
    del predi[0]  

    classwise_confidence=torch.tensor(predi)
    classwise_confidence_np=classwise_confidence.numpy()
    classwise_min = np.min(classwise_confidence_np, axis=1)
    if not random_tie_break:
        return multi_argmax(-classwise_min, n_instances)
    return shuffled_argmax(-classwise_min, n_instances)



def getBinaryTensor(inputTensor,boundary):
    one=torch.ones_like(inputTensor)
    zero=torch.zeros_like(inputTensor)
    return torch.where(inputTensor>boundary,one,zero)


def learner_query(model, Dataloader, query_strategy):

    query_result = query_strategy(model,Dataloader)#ids

    if isinstance(query_result, tuple):
        warnings.warn("Query strategies should no longer return the selected instances, "
                      "this is now handled by the query method. "
                      "Please return only the indices of the selected instances.", DeprecationWarning)
        return query_result

    sample=retrieve_rows(Dataloader, query_result)

    return query_result, sample


def retrieve_rows(Dataloader,index_list) :
    data=Dataloader.dataset
    result=[]
    for i in index_list:
        result.append(data[i])
    return result


