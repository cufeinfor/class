# !/usr/bin/env python
# -*- coding: UTF-8 -*-
'''
@Project ：ActiveLearningForHumanValue 
@File ：sentiment.py
@IDE  ：PyCharm 
@Author ：AmandaQiao
@Date ：2023/3/16 10:22 
@Description:
'''
import pandas as pd
#论文中的方法《Vader: A parsimonious rule-based model for sentiment analysis of social media text》
from nltk.sentiment.vader import SentimentIntensityAnalyzer

def getSentimentScore(text):
    sid = SentimentIntensityAnalyzer()
    sentiment_scores = sid.polarity_scores(text)
    sentiment_score = sentiment_scores['compound']
    return sentiment_score

if __name__ == '__main__':
    path='../dataset/label_for_version/k9-label/5801.csv'
    sentence=pd.read_csv(path)
    score=[]
    for sen in sentence['text']:
        sentiment_score = getSentimentScore(sen)
        score.append(sentiment_score)
    df=pd.DataFrame()
    df['id']=sentence['id']
    df['text']=sentence['text']
    df['score']=score
    df.to_csv('score.csv')
    # text="I used to like K9..now the interface is changing quickly. I especially dislike message action buttons moved to top. Please revert, or it's Bye k9"
    # s=getSentimentScore(text)
    # print(s)



