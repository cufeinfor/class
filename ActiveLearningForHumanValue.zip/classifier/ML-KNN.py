# !/usr/bin/env python
# -*- coding: UTF-8 -*-
'''
@Project ：ActiveLearningForHumanValue 
@File ：ML-KNN.py
@IDE  ：PyCharm 
@Author ：AmandaQiao
@Date ：2023/3/26 16:36 
@Description:
'''


# 导入相关模块
import pandas as pd
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.model_selection import train_test_split
from sklearn.metrics import hamming_loss
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import classification_report,coverage_error,label_ranking_average_precision_score,label_ranking_loss


if __name__ == '__main__':
    # 读取CSV文件，假设文件名为data.csv
    data = pd.read_csv("../jy/summary_valueSentiment.csv")
    data = data.dropna()
    # 提取文本信息和标签数据
    text = data.iloc[:, 1]  # 1列文本信息
    num = data.iloc[:, 13:24].values  # 11列数字信息
    y = data.iloc[:, 2:13]  # 11列的标签信息，每列都是0或者1 0表示不属于该类别，1表示属于该类别

    # 划分训练集和测试集
    # 划分训练集和测试集，比例为8:2
    text_train, text_test, num_train, num_test, y_train, y_test = train_test_split(text, num, y, test_size=0.2,
                                                                                   random_state=42)

    # 使用TF-IDF向量化文本信息
    vectorizer = TfidfVectorizer()
    text_train = vectorizer.fit_transform(text_train)
    text_test = vectorizer.transform(text_test)

    # 合并文本信息和数字信息
    from scipy.sparse import hstack

    X_train = hstack([text_train, num_train])
    X_test = hstack([text_test, num_test])

    # 选择一个距离度量函数，比如欧氏距离
    metric = "euclidean"

    # 选择一个合适的K值，比如5
    k = 5

    # 创建一个KNN分类器
    knn = KNeighborsClassifier(n_neighbors=k, metric=metric)

    # 训练模型
    knn.fit(X_train, y_train)

    # 预测测试集的标签集
    y_pred = knn.predict(X_test)

    # 评估模型性能，比如使用汉明损失函数
    # 对比预测结果和真实标签，计算模型的准确率、精确率、召回率和 F1 值等指标
    report = classification_report(y_test, y_pred)
    coverageError = coverage_error(y_test, y_pred)
    rankAvgScore = label_ranking_average_precision_score(y_test, y_pred)
    rankLoss = label_ranking_loss(y_test, y_pred)
    loss = hamming_loss(y_test, y_pred)
    print(report)
    print('coverageError:', coverageError)
    print('rankAvgScore:', rankAvgScore)
    print('rankLoss:', rankLoss)
    print("The hamming loss is:", loss)
    '''
    precision    recall  f1-score   support

           0       0.79      0.71      0.75       118
           1       0.54      0.67      0.60        70
           2       1.00      0.07      0.12        15
           3       0.00      0.00      0.00         3
           4       0.62      0.19      0.29        27
           5       0.67      0.20      0.31        20
           6       0.44      0.25      0.32        16
           7       0.00      0.00      0.00         1
           8       0.25      0.19      0.21        16
           9       0.00      0.00      0.00         9
          10       0.00      0.00      0.00        15

   micro avg       0.64      0.48      0.55       310
   macro avg       0.39      0.21      0.24       310
weighted avg       0.61      0.48      0.50       310
 samples avg       0.60      0.51      0.52       310

coverageError: 7.518134715025907
rankAvgScore: 0.5317619197152882
rankLoss: 0.5043733037256353
The hamming loss is: 0.11540273198304286
    '''