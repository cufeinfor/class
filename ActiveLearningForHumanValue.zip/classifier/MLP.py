# !/usr/bin/env python
# -*- coding: UTF-8 -*-
'''
@Project ：ActiveLearningForHumanValue 
@File ：NN.py
@IDE  ：PyCharm 
@Author ：AmandaQiao
@Date ：2023/3/25 17:20 
@Description:基于神经网络的多标签分类
'''

import torch#导入torch
import torch.nn as nn#神经网络都在这
import torch.nn.functional as F # 激励函数都在这
import torch
import torch.optim as optim
import numpy as np
import pandas as pd
from sklearn.preprocessing import StandardScaler
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics import classification_report,coverage_error,label_ranking_average_precision_score,label_ranking_loss
from torch.utils.data import DataLoader, TensorDataset



class MultiLabelPerceptron(nn.Module):
    def __init__(self, input_size, hidden_size, output_size):
        super().__init__()
        self.fc1 = nn.Linear(input_size, hidden_size)
        self.fc2 = nn.Linear(hidden_size, output_size)
        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        x = self.fc1(x)
        x = self.sigmoid(x)
        x = self.fc2(x)
        x = self.sigmoid(x)
        return x

    def train_model(self, train_loader, lr):
        loss_function = nn.BCELoss()
        optimizer = optim.Adam(self.parameters(), lr=lr)
        for i, (batch_x, batch_y) in enumerate(train_loader):
            optimizer.zero_grad()
            outputs = mlp(batch_x)
            loss = loss_function(outputs, batch_y)
            loss.backward()
            optimizer.step()
        return loss.item()

    def predict(self, x):
        outputs = self(x)
        predicted = np.round(outputs.detach().numpy())
        return predicted


if __name__ == '__main__':
    datapath = '../jy/summary_valueSentiment.csv'
    df = pd.read_csv(datapath, encoding='utf-8')
    keylist = df.columns[13:]
    # 对空文本进行处理
    # df['text'].fillna('default_value', inplace=True)
    df = df.dropna()
    # 特征提取：文本特征
    tfidf = TfidfVectorizer()
    text_feature = tfidf.fit_transform(df['text']).toarray()
    # 特征提取：数字特征
    scaler = StandardScaler()
    numeric_features = scaler.fit_transform(df[keylist])
    # 合并特征
    features = np.concatenate([text_feature, numeric_features], axis=1)
    # 标签处理
    labelKey = df.columns[2:13]
    labels = pd.get_dummies(df[labelKey])  # 将标签转换为one-hot编码
    # 划分训练集和测试集
    train_size = int(len(df) * 0.8)
    x_train, x_test = features[:train_size], features[train_size:]
    y_train, y_test = labels[:train_size], labels[train_size:]

    # 创建一个多标签分类模型的实例
    mlp = MultiLabelPerceptron(input_size=x_train.shape[1],hidden_size=64, output_size=y_train.shape[1])

    # 调用模型的 fit 方法，将训练集的特征和标签作为输入来训练模型

    # 创建 TensorDataset 对象
    train_data = TensorDataset(torch.Tensor(np.array(x_train)), torch.Tensor( np.array(y_train)))
    # 创建 DataLoader 对象
    train_loader = DataLoader(train_data, batch_size=32)
    epochs=150
    for t in range(epochs):
        loss=mlp.train_model(train_loader,lr=0.001)
        print(f"Epoch {t + 1}/{epochs}, Loss: {loss:.4f}")

    # 调用模型的 predict 方法，将测试集的特征作为输入来预测标签
    y_pred = mlp.predict(torch.Tensor(np.array(x_test)))

    # 对比预测结果和真实标签，计算模型的准确率、精确率、召回率和 F1 值等指标
    report = classification_report(y_test, y_pred)
    coverageError = coverage_error(y_test, y_pred)
    rankAvgScore = label_ranking_average_precision_score(y_test, y_pred)
    rankLoss = label_ranking_loss(y_test, y_pred)
    print(report)
    print('coverageError:', coverageError)
    print('rankAvgScore:', rankAvgScore)
    print('rankLoss:', rankLoss)


    '''
    batch=32,epochs=10, lr=0.001
                  precision    recall  f1-score   support

           0       0.62      1.00      0.77       117
           1       0.57      0.05      0.10        74
           2       0.00      0.00      0.00        18
           3       0.00      0.00      0.00         5
           4       0.00      0.00      0.00        14
           5       0.00      0.00      0.00        20
           6       0.00      0.00      0.00        26
           7       0.00      0.00      0.00         2
           8       0.00      0.00      0.00        16
           9       0.00      0.00      0.00        14
          10       0.00      0.00      0.00        10

   micro avg       0.62      0.38      0.47       316
   macro avg       0.11      0.10      0.08       316
weighted avg       0.36      0.38      0.31       316
 samples avg       0.61      0.42      0.47       316

coverageError: 8.321243523316062
rankAvgScore: 0.49919139582352107
rankLoss: 0.5844271732872769
Process finished with exit code 0


epoch=500,lr=0.001,batch=16 
Epoch 500/500, Loss: 0.0718
              precision    recall  f1-score   support

           0       0.71      0.68      0.70       117
           1       0.58      0.50      0.54        74
           2       0.86      0.33      0.48        18
           3       0.67      0.40      0.50         5
           4       0.50      0.36      0.42        14
           5       0.56      0.25      0.34        20
           6       0.45      0.19      0.27        26
           7       0.00      0.00      0.00         2
           8       0.33      0.19      0.24        16
           9       0.00      0.00      0.00        14
          10       0.00      0.00      0.00        10

   micro avg       0.63      0.45      0.53       316
   macro avg       0.42      0.26      0.32       316
weighted avg       0.57      0.45      0.49       316
 samples avg       0.57      0.49      0.50       316

coverageError: 7.538860103626943
rankAvgScore: 0.5075103365258812
rankLoss: 0.521804835924007

epoch=200,lr=0.001,batch=16 
Epoch 200/200, Loss: 0.4360
              precision    recall  f1-score   support

           0       0.73      0.76      0.74       117
           1       0.61      0.55      0.58        74
           2       0.80      0.22      0.35        18
           3       1.00      0.20      0.33         5
           4       0.57      0.29      0.38        14
           5       0.50      0.25      0.33        20
           6       0.60      0.23      0.33        26
           7       0.00      0.00      0.00         2
           8       0.33      0.12      0.18        16
           9       0.00      0.00      0.00        14
          10       0.00      0.00      0.00        10

   micro avg       0.66      0.48      0.56       316
   macro avg       0.47      0.24      0.29       316
weighted avg       0.60      0.48      0.51       316
 samples avg       0.59      0.52      0.52       316

coverageError: 7.295336787564767
rankAvgScore: 0.5279400219814734
rankLoss: 0.49726540011514103

epoch=150,lr=0.001,batch=16 
Epoch 150/150, Loss: 0.3768
              precision    recall  f1-score   support

           0       0.75      0.79      0.77       117
           1       0.61      0.58      0.60        74
           2       0.83      0.28      0.42        18
           3       0.00      0.00      0.00         5
           4       0.75      0.21      0.33        14
           5       0.57      0.20      0.30        20
           6       0.64      0.27      0.38        26
           7       0.00      0.00      0.00         2
           8       0.40      0.12      0.19        16
           9       0.00      0.00      0.00        14
          10       0.00      0.00      0.00        10

   micro avg       0.69      0.50      0.58       316
   macro avg       0.41      0.22      0.27       316
weighted avg       0.61      0.50      0.52       316
 samples avg       0.63      0.54      0.55       316

coverageError: 7.0310880829015545
rankAvgScore: 0.5573925786361026
rankLoss: 0.4707109959700633



epoch=100,lr=0.001,batch=16 
              precision    recall  f1-score   support

           0       0.72      0.72      0.72       117
           1       0.65      0.62      0.63        74
           2       0.80      0.22      0.35        18
           3       0.00      0.00      0.00         5
           4       1.00      0.14      0.25        14
           5       0.67      0.10      0.17        20
           6       0.71      0.19      0.30        26
           7       0.00      0.00      0.00         2
           8       0.50      0.12      0.20        16
           9       0.00      0.00      0.00        14
          10       0.00      0.00      0.00        10

   micro avg       0.69      0.46      0.55       316
   macro avg       0.46      0.19      0.24       316
weighted avg       0.64      0.46      0.49       316
 samples avg       0.59      0.50      0.51       316

coverageError: 7.357512953367876
rankAvgScore: 0.5359868111163454
rankLoss: 0.5092112838226828

epoch=100,lr=0.001,batch=32 
              precision    recall  f1-score   support

           0       0.72      0.73      0.72       117
           1       0.65      0.62      0.63        74
           2       0.50      0.06      0.10        18
           3       0.00      0.00      0.00         5
           4       1.00      0.07      0.13        14
           5       1.00      0.10      0.18        20
           6       0.50      0.12      0.19        26
           7       0.00      0.00      0.00         2
           8       1.00      0.06      0.12        16
           9       0.00      0.00      0.00        14
          10       0.00      0.00      0.00        10

   micro avg       0.69      0.44      0.54       316
   macro avg       0.49      0.16      0.19       316
weighted avg       0.65      0.44      0.46       316
 samples avg       0.61      0.49      0.51       316

coverageError: 7.476683937823834
rankAvgScore: 0.5314727586748318
rankLoss: 0.5154864709268854

epoch=150,lr=0.001,batch=32 
Epoch 150/150, Loss: 0.2257
              precision    recall  f1-score   support

           0       0.72      0.74      0.73       117
           1       0.64      0.64      0.64        74
           2       0.83      0.28      0.42        18
           3       0.00      0.00      0.00         5
           4       1.00      0.14      0.25        14
           5       0.75      0.15      0.25        20
           6       0.75      0.23      0.35        26
           7       0.00      0.00      0.00         2
           8       0.75      0.19      0.30        16
           9       0.00      0.00      0.00        14
          10       0.00      0.00      0.00        10

   micro avg       0.70      0.48      0.57       316
   macro avg       0.49      0.22      0.27       316
weighted avg       0.66      0.48      0.52       316
 samples avg       0.62      0.53      0.54       316

coverageError: 7.067357512953368
rankAvgScore: 0.5569738839168896
rankLoss: 0.48074265975820374
    '''

