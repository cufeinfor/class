# !/usr/bin/env python
# -*- coding: UTF-8 -*-
'''
@Project ：ActiveLearningForHumanValue 
@File ：read_recore.py
@IDE  ：PyCharm 
@Description:
'''
import argilla as rb
import pandas as pd

import torch
from torch.utils.data import DataLoader

from classifier.collote_data import collote_fn


def get_labeldata_fromrubrix(label):
    # label_list = {0:'Achievement', 1:'Self-direction', 2:'Hedonism', 3:'Security', 4:'Power', 5:'Stimulation', 6:'Benevolence',
    #               7:'Universalism', 8:'Conformity', 9:'Tradition', 10:'Other'}
    label_list=['Achievement','Self-direction','Hedonism', 'Security', 'Power', 'Stimulation','Benevolence', 'Universalism','Conformity','Tradition']
    label2id = {label: i for i, label in enumerate(label_list)}
    id2label = {i: label for i, label in enumerate(label_list)}

    one_hot_label=[0]*10
    label_num=[]
    for label_content in label:
        index=label2id[label_content]
        label_num.append(index)

    for id in label_num:
        one_hot_label[id]=1

    return one_hot_label

def predict_record(self,records):
    # pred_list=[]
    sample_dataloader=DataLoader(records,collate_fn=collote_fn)
    pred_list=[]
    with torch.no_grad():
        for X,y in sample_dataloader:
            logits = self.estimator(X)
            probs = logits.sigmoid()
            probs=probs.detach().numpy().tolist()
            pred_list.append(probs)
    return pred_list


if __name__ == '__main__':
    label1=['Achievement','Self-direction']
    label2=['Self-direction', 'Hedonism', 'Universalism','Security']
    a=get_labeldata_fromrubrix(label1)
    b=get_labeldata_fromrubrix(label2)
    print(a)
    print(b)
