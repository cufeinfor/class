# !/usr/bin/env python
# -*- coding: UTF-8 -*-
'''
@Project ：ActiveLearningForHumanValue 
@File ：active_learner.py
@IDE  ：PyCharm 
@Author ：Amanda
@Description:
'''
import os
import random
import re
import warnings
import datetime
import pandas as pd
import torch
from torch import nn
from torch.utils.data import DataLoader
from tqdm import tqdm
from classifier.collote_data import collote_fn
from classifier.metrics import metrics
from classifier.trainer import train_loop, test_loop
from transformers import AdamW, get_scheduler
import  wandb
wandb.login(key='ad48b7d7c2e2a931b98e486598a3d0b24c0adaec')
wandb.init(project='my-active-learning-pool-test2')

loss_fn = nn.BCEWithLogitsLoss()  # 


al_now_time = datetime.datetime.now()
al_temp_str = datetime.datetime.strftime(al_now_time, '%Y-%m-%d %H:%M:%S')
al_strs = re.sub(r"""[-|:| ]""", "_", al_temp_str)
al_base_path = f'learner/before_active_learning/checkpoint/'
al_log_path = al_base_path + al_strs
os.makedirs(al_log_path)




class MyActiveLearner():
    avg_loss = 0.
    def __init__(self, estimator, optimizer,lr_scheduler,query_strategy, train_dataloader, val_dataloader, data_pool,metrics):
    # def __init__(self, estimator, query_strategy, train_dataloader, val_dataloader,data_pool, metrics):
        self.estimator=estimator
        self.optimizer = optimizer
        self.lr_scheduler=lr_scheduler
        self.query_strategy = query_strategy
        self.train_dataloader=train_dataloader
        self.data_pool=data_pool
        self.val_dataloader=val_dataloader
        self.metrics = metrics
        assert callable(query_strategy), 'query_strategy must be callable'

    def learner_query(self,n_instances):
        query_result = self.query_strategy(self.estimator,self.data_pool,n_instances)
        if isinstance(query_result, tuple):
            warnings.warn("Query strategies should no longer return the selected instances, "
                          "this is now handled by the query method. "
                          "Please return only the indices of the selected instances.", DeprecationWarning)
            return query_result
        sample=retrieve_rows(self.data_pool, query_result)
        return query_result, sample


    def my_teach_new(self, query_result,records,start_epoch,epoch_num,wandb_project,wandb_run_id):

        patience = 10  
        best_average_precision = float('-inf') 
        epochs_without_improvement = 0  

        end_epoch = start_epoch + epoch_num

        train_dict_dataset = self.train_dataloader.dataset
        train_dict=train_dict_dataset.data
        lenth=len(train_dict.keys())
        print(lenth)
   
        completed_steps = start_epoch * lenth
        total_training_steps = completed_steps + (epoch_num * lenth)
        self.lr_scheduler = get_scheduler(
            "linear",
            optimizer=self.optimizer,
            num_warmup_steps=0,
            num_training_steps=total_training_steps,
        )
        for record in records:
            print(record)
            train_dict[lenth]=record
            lenth+=1
        self.train_dataloader=DataLoader(train_dict,batch_size=20, collate_fn=collote_fn)

        #更新标注池
        temp_pool_dict = self.data_pool.dataset
        temp_pool = list(temp_pool_dict.values())  
        sort_query_result=sorted(query_result,reverse=True)
        for i in sort_query_result:
            del temp_pool[i]
        datapool_df = pd.DataFrame(temp_pool)
        datapool_df_dict = datapool_df.to_dict(orient='index')
        update_data_pool = DataLoader(datapool_df_dict,collate_fn=collote_fn)
        self.data_pool=update_data_pool


        now_time = datetime.datetime.now()
        temp_str = datetime.datetime.strftime(now_time, '%Y-%m-%d %H:%M:%S')
        strs = re.sub(r"""[-|:| ]""", "_", temp_str)
        base_path = f'../saner/learner/learning_round/'
        temp_path = base_path + strs
        metric_path=temp_path+'/metric'
        model_path=temp_path+'/model'
        os.makedirs(metric_path)
        os.makedirs(model_path)

        epoch_data = []
        train_loss_data = []
        error_data = []
        rank_precision_data = []
        rank_loss_data = []
        average_precision_data = []
        ham_loss_data = []
        acc_score_data = []
        macro_precision_data = []
        micro_precsion_data = []
        weight_presion_data = []
        macro_recall_data = []
        micro_recall_data = []
        weight_recall_data = []
        macro_f1_data = []
        micro_f1_data = []
        weight_f1_data = []


        wandb.init(project=wandb_project, id=wandb_run_id, resume='must')

        wandb.config = {
            "learning_rate": self.optimizer.param_groups[0]['lr'],  
            "epochs": epoch_num,
            "batch_size": 20
        }

        metric_file = strs+'_'+f'metrics.csv'
        metric_path_current = metric_path + '/' + metric_file 

        for currentEpoch in range(start_epoch+1, end_epoch+1):
            print(f"Epoch {currentEpoch}/{end_epoch}\n-------------------------------")


            MyActiveLearner.avg_loss = train_loop(self.train_dataloader, self.estimator, loss_fn, self.optimizer, self.lr_scheduler,
                                      currentEpoch, MyActiveLearner.avg_loss)

error,rank_precision,rank_loss,average_precision,ham_loss,acc_score,macro_precision,micro_precsion,weight_presion,macro_recall,micro_recall,weight_recall,macro_f1,micro_f1,weight_f1 = test_loop(
                self.val_dataloader, self.estimator, mode='Valid')


            self.lr_scheduler.step()
            current_metric=[]

            current_metric.append({
                'epoch': currentEpoch,
                'train_loss': MyActiveLearner.avg_loss,
                'coverage_error': error,
                'rank_precision': rank_precision,
                'rank_loss': rank_loss,
                'average_precision': average_precision,
                'ham_loss': ham_loss,
                'acc_score': acc_score,
                'macro_precision': macro_precision,
                'micro_precision': micro_precsion,
                'weight_precision': weight_presion,
                'macro_recall': macro_recall,
                'micro_recall': micro_recall,
                'weight_recall': weight_recall,
                'macro_f1': macro_f1,
                'micro_f1': micro_f1,
                'weight_f1': weight_f1
            })

            current_metric_file = f'{metric_path}/epoch_{currentEpoch}_metric.csv'

            metrics_df = pd.DataFrame(current_metric)
            metrics_df.to_csv(current_metric_file, index=False)

            wandb.log({"error": error})
            wandb.log({"rank_precision": rank_precision})
            wandb.log({"rank_loss": rank_loss})
            wandb.log({"average_precision": average_precision})
            wandb.log({"ham_loss": ham_loss})
            wandb.log({"acc_score": acc_score})
            wandb.log({"macro_precision": macro_precision})
            wandb.log({"micro_precsion": micro_precsion})
            wandb.log({"weight_presion": weight_presion})
            wandb.log({"macro_recall": macro_recall})
            wandb.log({"micro_recall": micro_recall})
            wandb.log({"weight_recall": weight_recall})
            wandb.log({"macro_f1": macro_f1})
            wandb.log({"micro_f1": micro_f1})
            wandb.log({"weight_f1": weight_f1})
            # Optional
            wandb.watch(self.estimator)

            if average_precision > best_average_precision:
                best_average_precision = average_precision  
                epochs_without_improvement = 0  

            else:
                epochs_without_improvement += 1  
                if epochs_without_improvement >= patience:  
                    print("Early stopping triggered. Training stopped.")
                    break  

            epoch_data.append(currentEpoch)
            train_loss_data.append(MyActiveLearner.avg_loss)
            error_data.append(error)
            rank_precision_data.append(rank_precision)
            rank_loss_data.append(rank_loss)
            average_precision_data.append(average_precision)
            ham_loss_data.append(ham_loss)
            acc_score_data.append(acc_score)
            macro_precision_data.append(macro_precision)
            micro_precsion_data.append(micro_precsion)
            weight_presion_data.append(weight_presion)
            macro_recall_data.append(macro_recall)
            micro_recall_data.append(micro_recall)
            weight_recall_data.append(weight_recall)
            macro_f1_data.append(macro_f1)
            micro_f1_data.append(micro_f1)
            weight_f1_data.append(weight_f1)

            # if best_error> error and rank_precision> best_rank_pre and best_loss>rank_loss and average_precision > best_avg_pre:
            if self.metrics['best_error'] > error and rank_precision > self.metrics['best_rank_pre'] and self.metrics['best_loss'] > rank_loss and average_precision > self.metrics['best_avg_pre']:
                self.metrics['best_error'] = error
                self.metrics['best_rank_pre'] = rank_precision
                self.metrics['best_loss'] = rank_loss
                self.metrics['best_avg_pre'] = average_precision
                print('saving new weights...\n')
                file = f'epoch_{currentEpoch}_valid_error_{error:0.1f}_loss_{rank_loss:0.1f}_rpre_{(100 * rank_precision):0.1f}_avgpre_{(100 * average_precision):0.1f}_model_weights.bin'
                checkpoint = {
                    'epoch': currentEpoch,
                    'estimator': self.estimator.state_dict(),
                    'optimizer': self.optimizer.state_dict(),
                    'lr_schedule': self.lr_scheduler.state_dict(),
                    'wandb_run_id': wandb_run_id 
                    }
                check_path = al_log_path + '/' + file
                torch.save(checkpoint, check_path)
                state_checkpoint = torch.load(check_path)  
                model_state = state_checkpoint['estimator']  
                self.estimator.load_state_dict(model_state)

            elif average_precision > self.metrics['best_avg_pre']:
                self.metrics['best_avg_pre'] = average_precision
                print('saving new weights...\n')
                file = f'epoch_{currentEpoch}_valid_error_{error:0.1f}_loss_{rank_loss:0.1f}_rpre_{(100 * rank_precision):0.1f}_avgpre_{(100 * average_precision):0.1f}_model_weights.bin'
                checkpoint = {
                    'epoch': currentEpoch,
                    'estimator': self.estimator.state_dict(),
                    'optimizer': self.optimizer.state_dict(),
                    'lr_schedule': self.lr_scheduler.state_dict(),
                    'wandb_run_id': wandb_run_id 
                    }
                check_path = al_log_path + '/' + file
                torch.save(checkpoint, check_path)
                state_checkpoint = torch.load(check_path)  
                model_state = state_checkpoint['estimator'] 
                self.estimator.load_state_dict(model_state)

        data = pd.DataFrame({'epoch': epoch_data, 'train_loss':train_loss_data,'coverage_error': error_data,'rank_precision': rank_precision_data,'rank_loss': rank_loss_data,'average_precision': average_precision_data, 'ham_loss': ham_loss_data, 'acc_score': acc_score_data,'macro_precision': macro_precision_data, 'micro_precsion': micro_precsion_data,'weight_presion': weight_presion_data,'macro_recall': macro_recall_data, 'micro_recall': micro_recall_data, 'weight_recall': weight_recall_data,'macro_f1': macro_f1_data, 'micro_f1': micro_f1_data, 'weight_f1': weight_f1_data})
        data.to_csv(metric_path_current)

    def predict(self,query_result):
        sample=[]
        for i in query_result:
            x=self.data_pool.dataset[i]
            sample.append(x)
        sample_dataloader=DataLoader(sample,collate_fn=collote_fn)

        pred_list=[]
        with torch.no_grad():
            for index,X,y in tqdm(sample_dataloader):
                logits = self.estimator(X)
                probs = logits.sigmoid()
                probs=probs.detach().numpy().tolist()
                pred_list.append(probs)
        return pred_list

    def origin_test_metric(self):
        self.estimator.eval()
        i = 0
        error = 0
        rank_precision = 0
        rank_loss = 0
        average_precision = 0
        acc_score = 0
        macro_precision = 0
        micro_precsion = 0
        weight_presion = 0
        macro_recall = 0
        micro_recall = 0
        weight_recall = 0
        macro_f1 = 0
        micro_f1 = 0
        weight_f1 = 0
        with torch.no_grad():
            for X, y in self.val_dataloader:
                pred = self.estimator(X)
                c_error, top_precision, top_loss, avg_pre, acc, macro_pre, micro_pre, weight_pre, mac_recall, mic_recall, wei_recall, mac_f1, mic_f1, wei_f1 = metrics(
                    y, pred)
                error += c_error
                rank_precision += top_precision
                rank_loss += top_loss
                average_precision += avg_pre
                acc_score += acc
                macro_precision += macro_pre
                micro_precsion += micro_pre
                weight_presion += weight_pre
                macro_recall += mac_recall
                micro_recall += mic_recall
                weight_recall += wei_recall
                macro_f1 += mac_f1
                micro_f1 += mic_f1
                weight_f1 += wei_f1
                i += 1
        error /= i  
        rank_precision /= i
        rank_loss /= i
        average_precision /= i

        acc_score /= i
        macro_precision /= i
        micro_precsion /= i
        weight_presion /= i
        macro_recall /= i
        micro_recall /= i
        weight_recall /= i
        macro_f1 /= i
        micro_f1 /= i
        weight_f1 /= i
        return error, rank_precision, rank_loss, average_precision, acc_score, macro_precision, micro_precsion, weight_presion, macro_recall, micro_recall, weight_recall, macro_f1, micro_f1, weight_f1


    def update_test_metric(self):
        self.estimator.eval()
        i = 0
        error = 0
        rank_precision = 0
        rank_loss = 0
        average_precision = 0
        acc_score = 0
        macro_precision = 0
        micro_precsion = 0
        weight_presion = 0
        macro_recall = 0
        micro_recall = 0
        weight_recall = 0
        macro_f1 = 0
        micro_f1 = 0
        weight_f1 = 0
        with torch.no_grad():
            for X, y in self.train_dataloader:
                pred = self.estimator(X)
                c_error, top_precision, top_loss, avg_pre, acc, macro_pre, micro_pre, weight_pre, mac_recall, mic_recall, wei_recall, mac_f1, mic_f1, wei_f1 = metrics(
                    y, pred)
                error += c_error
                rank_precision += top_precision
                rank_loss += top_loss
                average_precision += avg_pre
                acc_score += acc
                macro_precision += macro_pre
                micro_precsion += micro_pre
                weight_presion += weight_pre
                macro_recall += mac_recall
                micro_recall += mic_recall
                weight_recall += wei_recall
                macro_f1 += mac_f1
                micro_f1 += mic_f1
                weight_f1 += wei_f1
                i += 1
        error /= i 
        rank_precision /= i
        rank_loss /= i
        average_precision /= i

        acc_score /= i
        macro_precision /= i
        micro_precsion /= i
        weight_presion /= i
        macro_recall /= i
        micro_recall /= i
        weight_recall /= i
        macro_f1 /= i
        micro_f1 /= i
        weight_f1 /= i
        return error, rank_precision, rank_loss, average_precision, acc_score, macro_precision, micro_precsion, weight_presion, macro_recall, micro_recall, weight_recall, macro_f1, micro_f1, weight_f1



def retrieve_rows(Dataloader,index_list) :
    data=Dataloader.dataset
    result=[]
    for i in index_list:
        result.append(data[i])
    return result

def getBinaryTensor(inputTensor, boundary):
    one = torch.ones_like(inputTensor)
    zero = torch.zeros_like(inputTensor)
    return torch.where(inputTensor > boundary, one, zero)


