# !/usr/bin/env python
# -*- coding: UTF-8 -*-
'''
@Project ：ActiveLearningForHumanValue 
@File ：CML.py
@IDE  ：PyCharm 
@Author ：AmandaQiao
@Date ：2023/3/26 10:31 
@Description:CML是一种基于聚类算法的多标签分类模型，它利用聚类技术来划分标签空间，并在每个子空间中训练一个单标签分类器。
下面是一个使用Python和scikit-multilearn库实现的CML多标签分类算法的代码示例，它使用了k-means聚类和随机森林分类器。
'''


# 导入所需的库
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import TfidfVectorizer
from skmultilearn.cluster import MatrixLabelSpaceClusterer
from skmultilearn.problem_transform import LabelPowerset
from sklearn.cluster import KMeans
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import classification_report,coverage_error,label_ranking_average_precision_score,label_ranking_loss

if __name__ == '__main__':
    # 读取CSV文件，假设文件名为data.csv
    data = pd.read_csv("../jy/summary_valueSentiment.csv")
    data = data.dropna()
    # 提取文本信息和标签数据
    text = data.iloc[:, 1]  # 1列文本信息
    num = data.iloc[:, 13:24].values  # 11列数字信息
    y = data.iloc[:, 2:13]  # 11列的标签信息，每列都是0或者1 0表示不属于该类别，1表示属于该类别

    # 划分训练集和测试集，比例为8:2
    text_train, text_test, num_train, num_test, y_train, y_test = train_test_split(text, num, y, test_size=0.2,
                                                                                   random_state=42)

    # 使用TF-IDF向量化文本信息
    vectorizer = TfidfVectorizer()
    text_train = vectorizer.fit_transform(text_train)
    text_test = vectorizer.transform(text_test)

    # 合并文本信息和数字信息
    from scipy.sparse import hstack

    X_train = hstack([text_train, num_train])
    X_test = hstack([text_test, num_test])

    # 使用k-means聚类划分标签空间，假设聚类数为5
    clusterer = MatrixLabelSpaceClusterer(clusterer=KMeans(n_clusters=5))

    # 使用随机森林分类器作为基分类器，并使用LabelPowerset方法将每个子空间转化为单标签问题
    classifier = LabelPowerset(classifier=RandomForestClassifier())

    # 训练模型
    classifier.fit(X_train, y_train)

    # 预测测试集的标签
    y_pred = classifier.predict(X_test)

    # 打印预测结果的前5行
    print(y_pred[:5])

    # 对比预测结果和真实标签，计算模型的准确率、精确率、召回率和 F1 值等指标
    report = classification_report(y_test, y_pred.toarray())
    coverageError = coverage_error(y_test, y_pred.toarray())
    rankAvgScore = label_ranking_average_precision_score(y_test, y_pred.toarray())
    rankLoss = label_ranking_loss(y_test, y_pred.toarray())
    print(report)
    print('coverageError:', coverageError)
    print('rankAvgScore:', rankAvgScore)
    print('rankLoss:', rankLoss)

    '''
                  precision    recall  f1-score   support

           0       0.77      0.83      0.80       118
           1       0.60      0.54      0.57        70
           2       0.00      0.00      0.00        15
           3       0.00      0.00      0.00         3
           4       0.00      0.00      0.00        27
           5       0.00      0.00      0.00        20
           6       0.00      0.00      0.00        16
           7       0.00      0.00      0.00         1
           8       0.00      0.00      0.00        16
           9       0.00      0.00      0.00         9
          10       0.50      0.07      0.12        15

   micro avg       0.71      0.44      0.54       310
   macro avg       0.17      0.13      0.14       310
weighted avg       0.45      0.44      0.44       310
 samples avg       0.71      0.52      0.57       310

coverageError: 7.269430051813472
rankAvgScore: 0.596946145391742
rankLoss: 0.48454231433506045

    '''