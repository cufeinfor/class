# !/usr/bin/env python
# -*- coding: UTF-8 -*-
'''
@Project ：ActiveLearningForHumanValue 
@File ：OVR.py
@IDE  ：PyCharm 
@Author ：AmandaQiao
@Date ：2023/3/25 16:04 
@Description:基于svm,lr,xgboost等的多标签分类
'''
import numpy as np
import pandas as pd
from sklearn.preprocessing import StandardScaler
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.multiclass import OneVsRestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import classification_report,coverage_error,label_ranking_average_precision_score,label_ranking_loss
from sklearn.svm import SVC
from sklearn.tree import DecisionTreeClassifier
from sklearn.multioutput import MultiOutputClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.preprocessing import MultiLabelBinarizer
import xgboost as xgb
from multiSmote.multi_smote import MultiSmote as mlsmote




if __name__ == '__main__':
    datapath='../jy/summary_valueSentiment.csv'
    # savepath='../jy/summary_valueSentiment_standard.csv'
    df=pd.read_csv(datapath,encoding='utf-8')
    keylist=df.columns[13:]
    # dataStandardization(datapath,keylist,savepath)
    # 对空文本进行处理
    # df['text'].fillna('default_value', inplace=True)
    df = df.dropna()
    # 特征提取：文本特征
    tfidf = TfidfVectorizer()
    text_feature= tfidf.fit_transform(df['text']).toarray()
    ##weight就是模型的输入，它的大小(m,n),m是文本个数，n是词库的大小.  (m, n) 0.3365
    # 特征提取：数字特征
    scaler = StandardScaler()
    numeric_features = scaler.fit_transform(df[keylist])
    # 合并特征
    features = np.concatenate([text_feature, numeric_features], axis=1)

    # 标签处理
    labelKey = df.columns[2:13]
    labels = pd.get_dummies(df[labelKey])#将标签转换为二进制编码

    # 划分训练集和测试集
    train_size = int(len(df) * 0.8)
    x_train, x_test = features[:train_size], features[train_size:]
    y_train, y_test = labels[:train_size].values, labels[train_size:].values
    print(np.isnan(x_train).sum())

    # 处理每个标签的采样,采用smote算法进行过采样
    smote = mlsmote()
    X_resampled, y_resampled = smote.multi_smote(x_train, y_train)

    # 模型训练
    # clf = OneVsRestClassifier(LogisticRegression())#逻辑回归用于多标签分类，不需要转换为多标签分类器
    # clf=OneVsRestClassifier(SVC(kernel='linear'))#支持向量机用于多标签分类,不需要转换为多标签分类器
    # clf = MultiOutputClassifier(xgb.XGBClassifier()) # 使用MultiOutputClassifier包装XGBoost分类器
    # clf = DecisionTreeClassifier()    # 构建决策树分类器，需要转换为多标签分类器
    clf = RandomForestClassifier()# 构建随机森林分类器，需要转换为多标签分类器
    # clf= KNeighborsClassifier(n_neighbors=10)# 构建KNN分类器，总出bug，算了
    clf = MultiOutputClassifier(clf)# 将分类器转换为多标签分类器

    clf.fit(X_resampled, y_resampled)
    # 模型预测
    y_pred = clf.predict(x_test)

    # 模型评估
    print(classification_report(y_test, y_pred))
    coverageError = coverage_error(y_test, y_pred)
    rankAvgScore=label_ranking_average_precision_score(y_test, y_pred)
    rankLoss=label_ranking_loss(y_test, y_pred)

    print('coverageError:',coverageError)
    print('rankAvgScore:',rankAvgScore)
    print('rankLoss:',rankLoss)

    '''
    SVC(kernel='linear')，加smote后效果一样
                  precision    recall  f1-score   support

           0       0.76      0.77      0.76       117
           1       0.61      0.58      0.59        74
           2       1.00      0.11      0.20        18
           3       0.00      0.00      0.00         5
           4       1.00      0.14      0.25        14
           5       1.00      0.05      0.10        20
           6       0.00      0.00      0.00        26
           7       0.00      0.00      0.00         2
           8       0.00      0.00      0.00        16
           9       0.00      0.00      0.00        14
          10       0.00      0.00      0.00        10

   micro avg       0.71      0.44      0.54       316
   macro avg       0.40      0.15      0.17       316
weighted avg       0.59      0.44      0.45       316
 samples avg       0.62      0.50      0.52       316
 coverageError: 7.419689119170984
rankAvgScore: 0.5384204741717701
rankLoss: 0.5093120322394934
 
 LogisticRegression()，加smote后效果一样
 precision    recall  f1-score   support

           0       0.72      0.85      0.78       117
           1       0.62      0.57      0.59        74
           2       0.00      0.00      0.00        18
           3       0.00      0.00      0.00         5
           4       0.00      0.00      0.00        14
           5       0.00      0.00      0.00        20
           6       0.00      0.00      0.00        26
           7       0.00      0.00      0.00         2
           8       0.00      0.00      0.00        16
           9       0.00      0.00      0.00        14
          10       0.00      0.00      0.00        10

   micro avg       0.68      0.45      0.54       316
   macro avg       0.12      0.13      0.12       316
weighted avg       0.41      0.45      0.43       316
 samples avg       0.64      0.51      0.54       316
 coverageError: 7.300518134715026
rankAvgScore: 0.5575600565237875
rankLoss: 0.49575417386298215
 
 决策树分类器结果
 
               precision    recall  f1-score   support

           0       0.71      0.70      0.70       117
           1       0.48      0.57      0.52        74
           2       0.61      0.61      0.61        18
           3       1.00      0.20      0.33         5
           4       0.42      0.36      0.38        14
           5       0.30      0.15      0.20        20
           6       0.60      0.35      0.44        26
           7       0.00      0.00      0.00         2
           8       0.38      0.31      0.34        16
           9       0.20      0.14      0.17        14
          10       0.25      0.20      0.22        10

   micro avg       0.55      0.51      0.53       316
   macro avg       0.45      0.33      0.36       316
weighted avg       0.55      0.51      0.52       316
 samples avg       0.50      0.54      0.49       316

coverageError: 7.331606217616581
rankAvgScore: 0.4744386873920557
rankLoss: 0.4989493379389752
决策树+smote结果，样本少的结果有所提升
              precision    recall  f1-score   support

           0       0.70      0.69      0.70       117
           1       0.49      0.57      0.53        74
           2       0.69      0.61      0.65        18
           3       0.67      0.40      0.50         5
           4       0.55      0.43      0.48        14
           5       0.33      0.10      0.15        20
           6       0.65      0.42      0.51        26
           7       0.00      0.00      0.00         2
           8       0.46      0.38      0.41        16
           9       0.18      0.14      0.16        14
          10       0.00      0.00      0.00        10

   micro avg       0.57      0.52      0.54       316
   macro avg       0.43      0.34      0.37       316
weighted avg       0.56      0.52      0.53       316
 samples avg       0.50      0.54      0.49       316

coverageError: 7.27979274611399
rankAvgScore: 0.4768173967655837
rankLoss: 0.49727979274611395


#随机森林分类器结果 ，加smote后效果一样
       precision    recall  f1-score   support

           0       0.78      0.81      0.79       117
           1       0.59      0.51      0.55        74
           2       0.00      0.00      0.00        18
           3       0.00      0.00      0.00         5
           4       0.00      0.00      0.00        14
           5       0.00      0.00      0.00        20
           6       0.00      0.00      0.00        26
           7       0.00      0.00      0.00         2
           8       0.00      0.00      0.00        16
           9       0.00      0.00      0.00        14
          10       0.00      0.00      0.00        10

   micro avg       0.72      0.42      0.53       316
   macro avg       0.12      0.12      0.12       316
weighted avg       0.43      0.42      0.42       316
 samples avg       0.66      0.49      0.54       316

coverageError: 7.357512953367876
rankAvgScore: 0.5647825404302095
rankLoss: 0.5087507196315486
#随机森林+smote结果
              precision    recall  f1-score   support

           0       0.77      0.82      0.79       117
           1       0.61      0.54      0.57        74
           2       0.00      0.00      0.00        18
           3       0.00      0.00      0.00         5
           4       0.00      0.00      0.00        14
           5       0.00      0.00      0.00        20
           6       0.00      0.00      0.00        26
           7       0.00      0.00      0.00         2
           8       0.00      0.00      0.00        16
           9       0.00      0.00      0.00        14
          10       0.00      0.00      0.00        10

   micro avg       0.71      0.43      0.54       316
   macro avg       0.12      0.12      0.12       316
weighted avg       0.43      0.43      0.43       316
 samples avg       0.66      0.51      0.54       316

coverageError: 7.269430051813472
rankAvgScore: 0.5659601193279956
rankLoss: 0.49792746113989633



xgboost,+smote结果也是一样的
              precision    recall  f1-score   support

           0       0.80      0.82      0.81       117
           1       0.55      0.50      0.52        74
           2       0.75      0.17      0.27        18
           3       0.00      0.00      0.00         5
           4       0.50      0.14      0.22        14
           5       0.60      0.15      0.24        20
           6       0.33      0.04      0.07        26
           7       0.00      0.00      0.00         2
           8       0.67      0.12      0.21        16
           9       0.43      0.21      0.29        14
          10       1.00      0.10      0.18        10

   micro avg       0.69      0.47      0.56       316
   macro avg       0.51      0.21      0.26       316
weighted avg       0.64      0.47      0.50       316
 samples avg       0.62      0.52      0.54       316

coverageError: 7.269430051813472
rankAvgScore: 0.5549680745276607
rankLoss: 0.48951599638128135

Process finished with exit code 0



    '''