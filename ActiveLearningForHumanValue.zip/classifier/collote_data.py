# !/usr/bin/env python
# -*- coding: UTF-8 -*-
'''
@Project ：ActiveLearningForHumanValue 
@File ：process_data.py
@IDE  ：PyCharm 
@Author ：AmandaQiao
@Date ：2022/9/26 10:22 
@Description:
'''
import pandas as pd
# 模板代码

import torch
# from torch.utils.data import DataLoader
from transformers import AutoTokenizer

# model = "bert-base-uncased"  # 使用的模型名称,原始版本
model='D:/PycharmWorkspace/ActiveLearningForHumanValue/bert/bert-base-uncased'
tokenizer = AutoTokenizer.from_pretrained(model)  # 实现文本中word和id的编码对应转换，一般是一个模型对应一个tokenizer，因为不同模型的编码方法和格式不一样

# 数据批量处理的一个函数，对每个Batch_size的数据样本进行处理，就是把sample和label分离出来
def collote_fn(batch_samples):  # 传入批处理的数据，#在不同下游任务中，主要修改这个样本数据函数即可，即获得X和Y
    batch_text = []
    batch_label = []
    batch_id=[]#保存到id，新增此行代码
    for sample in batch_samples:  # 拿到每个数据的text和label
        batch_id.append(sample['id'])
        batch_text.append('' if pd.isna(sample['text']) else sample['text'] )
        batch_label.append(sample['label'])
    # 对每个text做id转换
    X = tokenizer(  # 支持对空值的处理。不同模型的tokenizer不一样，本tokenizer是实例化了一个bert的tokenizer
        batch_text,
        padding=True,  # 最长的长度默认是512，会补位到512，或者是padding=max_length
        truncation=True,  # 超过最大长度会被截断
        return_tensors="pt",# pytorch，返回类型
        # 以bert为例，以下参数可选择性设置或者不设置
        # return_token_type_ids = True,# 第一个句子和特殊符号所在的位置都是0，第二个句子的位置都是1
        # return_attention_mask = True,# 特殊符号的位置是1，其他位置是0
        # return_special_tokens_mask = True,# padding位置是0，其他位置是1
        # return_length = True # 返回句子长度
    )
    # input_ids=X['input_ids']
    y = torch.tensor(batch_label)
    return batch_id,X, y
    # 注意，如果要分别去input_id等之类的，可以直接从X中获得，input_ids=X['input_ids']

#如果需要单独获得input_ids等信息，则用这个
def collote_fn_all(batch_samples):  # 传入批处理的数据，#在不同下游任务中，主要修改这个样本数据函数即可，即获得X和Y
    batch_text = []
    batch_label = []
    for sample in batch_samples:  # 拿到每个数据的text和label
        batch_text.append(sample['text'])
        batch_label.append(sample['label'])
    # 对每个text做id转换
    X = tokenizer(  # 不同模型的tokenizer不一样，本tokenizer是实例化了一个bert的tokenizer
        batch_text,
        padding=True,  # 最长的长度默认是512，会补位到512，或者是padding=max_length
        truncation=True,  # 超过最大长度会被截断
        return_tensors="pt",# pytorch，返回类型
        # 以bert为例，以下参数可选择性设置或者不设置
        return_token_type_ids = True,# 第一个句子和特殊符号所在的位置都是0，第二个句子的位置都是1
        return_attention_mask = True,# 特殊符号的位置是1，其他位置是0
        return_special_tokens_mask = True,# padding位置是0，其他位置是1
        return_length = True # 返回句子长度
    )
    input_ids=X['input_ids']
    token_type_ids=X['token_type_ids']
    attention_mask=X['attention_mask']
    # special_tokens_mask=X['special_tokens_mask']
    y = torch.tensor(batch_label)#label
    return input_ids, token_type_ids,attention_mask,y
    # 注意，如果要分别去input_id等之类的，可以直接从X中获得，input_ids=X['input_ids']
