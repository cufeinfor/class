# !/usr/bin/env python
# -*- coding: UTF-8 -*-
'''
@Project ：ActiveLearningForHumanValue 
@File ：bert+smote.py
@IDE  ：PyCharm 
@Author ：AmandaQiao
@Date ：2023/3/27 16:59 
@Description:
'''


from classifier.collote_data import collote_fn
# 基于最初的train_data，得出基础的model
import os
import re
import torch
from classifier.trainer import train_loop, test_loop

from torch import nn
from transformers import AdamW, get_scheduler
import datetime
from classifier.multi_laber_classifier import classifer_model
import pandas as pd

from classifier.load_data import LoadData
from torch.utils.data import DataLoader
import numpy as np
import pandas as pd
from sklearn.preprocessing import StandardScaler
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.neighbors import NearestNeighbors

if __name__ == '__main__':

    datapath = '../jy/summary_valueSentiment.csv'
    # savepath='../jy/summary_valueSentiment_standard.csv'
    df = pd.read_csv(datapath, encoding='utf-8')
    keylist = df.columns[13:]
    # dataStandardization(datapath,keylist,savepath)
    # 对空文本进行处理
    # df['text'].fillna('default_value', inplace=True)
    df = df.dropna()
    # 特征提取：文本特征
    tfidf = TfidfVectorizer()
    text_feature = tfidf.fit_transform(df['text']).toarray()
    ##weight就是模型的输入，它的大小(m,n),m是文本个数，n是词库的大小.  (m, n) 0.3365
    # 特征提取：数字特征
    scaler = StandardScaler()
    numeric_features = scaler.fit_transform(df[keylist])
    # 合并特征
    features = np.concatenate([text_feature, numeric_features], axis=1)

    # 标签处理
    labelKey = df.columns[2:13]
    labels = pd.get_dummies(df[labelKey])  # 将标签转换为one-hot编码

    # 划分训练集和测试集
    train_size = int(len(df) * 0.8)
    x_train, x_test = features[:train_size], features[train_size:]
    y_train, y_test = labels[:train_size], labels[train_size:]




