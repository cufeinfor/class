import os
import numpy as np
from transformers import RobertaTokenizer, RobertaModel
import torch
from concurrent.futures import ThreadPoolExecutor, as_completed
import multiprocessing
import time

# Global variables for model and tokenizer
tokenizer = None
model = None


def initialize_model(gpu_id):
    global tokenizer, model
    tokenizer = RobertaTokenizer.from_pretrained("./roberta-large")
    model = RobertaModel.from_pretrained("./roberta-large")
    device = torch.device(f"cuda:{gpu_id}")
    model = model.to(device)
    return f"Initialized model on GPU {gpu_id}"


def get_cls_embedding(text, gpu_id):
    device = torch.device(f"cuda:{gpu_id}")
    inputs = tokenizer(text, return_tensors="pt", padding=True, truncation=True, max_length=512)
    inputs = {k: v.to(device) for k, v in inputs.items()}
    with torch.no_grad():
        outputs = model(**inputs)
    return outputs.last_hidden_state[:, 0, :].cpu().numpy().flatten()


def read_text_from_file(file_path):
    with open(file_path, 'r', encoding='utf-8') as file:
        return file.read()


def save_embedding(embedding, file_path):
    np.save(file_path, embedding)


def process_file(args):
    readme_path, embeddings_folder, gpu_id = args
    filename = os.path.basename(readme_path)
    embedding_path = os.path.join(embeddings_folder, filename.replace('.txt', '.npy'))

    # Skip if the file already exists
    if os.path.exists(embedding_path):
        return f"Skipped existing embedding for {filename} on GPU {gpu_id}"

    text = read_text_from_file(readme_path)
    embedding = get_cls_embedding(text, gpu_id)
    save_embedding(embedding, embedding_path)

    return f"Processed and saved embedding for {filename} on GPU {gpu_id}"


def process_files_on_device(device_id, files, embeddings_folder, num_threads):
    initialize_model(device_id)
    with ThreadPoolExecutor(max_workers=num_threads) as executor:
        args = [(f, embeddings_folder, device_id) for f in files]
        future_to_file = {executor.submit(process_file, arg): arg for arg in args}
        for future in as_completed(future_to_file):
            print(future.result())


def distribute_files(files, num_gpus):
    files_per_gpu = len(files) // num_gpus
    distributed_files = [files[i:i + files_per_gpu] for i in range(0, len(files), files_per_gpu)]

    # Adjust if there are remaining files
    for i in range(len(files) % num_gpus):
        distributed_files[i].append(files[num_gpus * files_per_gpu + i])

    return distributed_files


def process_and_save_embeddings(readme_folder, embeddings_folder, num_gpus, gpu_threads):
    if not os.path.exists(embeddings_folder):
        os.makedirs(embeddings_folder)

    files = [os.path.join(readme_folder, f) for f in os.listdir(readme_folder) if f.endswith('_combined.txt')]
    distributed_files = distribute_files(files, num_gpus)

    processes = []
    for i in range(num_gpus):
        p = multiprocessing.Process(target=process_files_on_device,
                                    args=(i, distributed_files[i], embeddings_folder, gpu_threads))
        processes.append(p)
        p.start()

    for p in processes:
        p.join()


def load_all_embeddings(embeddings_folder):
    embeddings = {}
    for filename in os.listdir(embeddings_folder):
        if filename.endswith('.npy'):
            file_path = os.path.join(embeddings_folder, filename)
            project_id = filename.split('_')[0]
            embeddings[project_id] = np.load(file_path)
    return embeddings


if __name__ == "__main__":
    readme_folder = r"F:\TSE2024\readme_with_des_history_base"
    embeddings_folder = r"F:\TSE2024\embeddings_all_history"
    num_gpus = torch.cuda.device_count()  # Get the number of available GPUs
    gpu_threads = 24

    start_time = time.time()

    process_and_save_embeddings(readme_folder, embeddings_folder, num_gpus, gpu_threads)

    end_time = time.time()
    print(f"Total processing time: {end_time - start_time:.2f} seconds")

    all_embeddings = load_all_embeddings(embeddings_folder)
    print(f"Loaded embeddings for {len(all_embeddings)} projects")
    for project_id, embedding in list(all_embeddings.items())[:5]:
        print(f"Project ID: {project_id}, Embedding shape: {embedding.shape}")