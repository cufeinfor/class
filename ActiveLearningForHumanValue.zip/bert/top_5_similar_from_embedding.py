import os
import numpy as np
import torch
import concurrent.futures
from tqdm import tqdm
import nltk
from nltk.tokenize import word_tokenize

# 指定文件夹路径
embeddings_folder = r'F:\TSE2024\embeddings_all_history'
pre_hot_folder = r'F:\TSE2024\pre_hot_topic'
readme_folder = r'F:\TSE2024\readme_with_des_history_base'
output_folder = r'F:\TSE2024\prompt_for_short_token_incontext_learning'

# Download the necessary NLTK data
nltk.download('punkt')

# 获取pre_hot的id列表
pre_hot = [filename[:-4] for filename in os.listdir(pre_hot_folder) if filename.endswith('.txt')]

# 读取pre_hot的embeddings
pre_hot_embeddings = {}
for id in pre_hot:
    embedding_path = os.path.join(embeddings_folder, f"{id}_combined.npy")
    if os.path.exists(embedding_path):
        pre_hot_embeddings[id] = torch.from_numpy(np.load(embedding_path)).cuda()

# 将pre_hot_embeddings转换为一个大的张量
pre_hot_ids = list(pre_hot_embeddings.keys())
pre_hot_tensor = torch.stack(list(pre_hot_embeddings.values()))

def limit_tokens(text, max_tokens=200):
    tokens = word_tokenize(text)
    return ' '.join(tokens[:max_tokens])

def read_file_content(folder, filename):
    file_path = os.path.join(folder, filename)
    if os.path.exists(file_path):
        with open(file_path, 'r', encoding='utf-8') as file:
            content = file.read().strip()
            return f"example\n{limit_tokens(content)}"
    return "example\n"

def read_file_content_topic(folder, filename):
    file_path = os.path.join(folder, filename)
    if os.path.exists(file_path):
        with open(file_path, 'r', encoding='utf-8') as file:
            content = file.read().strip()
            return f"{limit_tokens(content)}"
    return "\n"

def process_file(filename):
    if filename.endswith('.npy'):
        current_id = filename[:-4]  # 移除 '.npy' 后缀
        print(current_id)
        current_embedding = torch.from_numpy(np.load(os.path.join(embeddings_folder, filename))).cuda()

        # 计算欧氏距离
        distances = torch.cdist(current_embedding.unsqueeze(0), pre_hot_tensor).squeeze()

        # 获取最近的5个id
        _, indices = distances.topk(5, largest=False)
        closest_5 = [pre_hot_ids[i] for i in indices.cpu().numpy()]

        return current_id, closest_5
    return None

# 使用24线程处理文件
results = {}
with concurrent.futures.ThreadPoolExecutor(max_workers=24) as executor:
    future_to_filename = {executor.submit(process_file, filename): filename for filename in
                          os.listdir(embeddings_folder)}
    for future in tqdm(concurrent.futures.as_completed(future_to_filename), total=len(future_to_filename)):
        result = future.result()
        if result:
            current_id, closest_5 = result
            results[current_id] = closest_5

# 确保输出文件夹存在
os.makedirs(output_folder, exist_ok=True)

# Processing results
for target, closest in results.items():
    output_content = []

    # Add the instruction at the beginning of each file
    output_content.append("You are an open-source software topic labeler, and your task is to label the topic of a project according to the following text of the project description and readme files. I'll show you some examples, and the target text. The answers are organized as follows: topic: topic1 topic2....\n")

    # Process the 5 closest ids in reverse order
    for close_id in reversed(closest):
        close_readme = read_file_content(readme_folder, f"{close_id}_combined.txt")
        close_pre_hot = read_file_content_topic(pre_hot_folder, f"{close_id}.txt")
        output_content.append(f"{close_id}:\n{close_readme}\n{close_pre_hot}\n")

    # Process target id
    output_content.append("target text: \n")
    target_readme = read_file_content_topic(readme_folder, f"{target}_combined.txt")
    target_pre_hot = read_file_content_topic(pre_hot_folder, f"{target}.txt")
    output_content.append(f"{target}:\n{target_readme}\n{target_pre_hot}\n")

    # Add the content of target.txt from readme_with_des_history_base
    target_full_content_path = os.path.join(readme_folder, f"{target}.txt")
    if os.path.exists(target_full_content_path):
        with open(target_full_content_path, 'r', encoding='utf-8') as file:
            target_full_content = file.read().strip()
        output_content.append(f"\n{target_full_content}")

    # Write to output file
    output_file_path = os.path.join(output_folder, f"{target}.txt")
    with open(output_file_path, 'w', encoding='utf-8') as output_file:
        output_file.write("\n".join(output_content))

    print(f"Processed {target}")

print("All files have been processed and saved.")