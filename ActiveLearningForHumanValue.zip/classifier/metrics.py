# !/usr/bin/env python
# -*- coding: UTF-8 -*-
'''
@Project ：ActiveLearningForHumanValue 
@File ：metrics.py
@IDE  ：PyCharm 
@Author ：AmandaQiao
@Date ：2022/9/26 20:07 
@Description:
'''
import torch
from sklearn.metrics import coverage_error, label_ranking_average_precision_score, label_ranking_loss, \
    average_precision_score, accuracy_score, precision_score, recall_score, f1_score,hamming_loss,classification_report

def metrics(y,pred):#对每条数据来讲
    '''
    :param y: 原始标签，0、1
    :param pred: 模型直接输出的，需要sigmoid后才为概率
    :return:
    '''
    # pred = model(X)
    pred = pred.sigmoid()
    # 这些指标都已经是计算过平均的指标，如果需要计算整体的，则需要先求和，再*batch_size/len(data)
    # 用概率值直接计算的指标

    c_error = coverage_error(y, pred)#越小越好
    top_precision = label_ranking_average_precision_score(y, pred)#越高越好
    top_loss = label_ranking_loss(y, pred)#越小越好
    avg_pre = average_precision_score(y, pred)#越高越好
    # 用label直接计算的指标
    pred_label = getBinaryTensor(pred, 0.5)  # 阈值的选择会影响
    ham_loss = hamming_loss(y, pred_label)
    acc = accuracy_score(y, pred_label)
    macro_pre = precision_score(y, pred_label, average='macro')
    micro_pre = precision_score(y, pred_label, average='micro')
    weight_pre = precision_score(y, pred_label, average='weighted')
    mac_recall = recall_score(y, pred_label, average='macro')
    mic_recall = recall_score(y, pred_label, average='micro')
    wei_recall = recall_score(y, pred_label, average='weighted')
    mac_f1 = f1_score(y, pred_label, average='macro')
    mic_f1 = f1_score(y, pred_label, average='micro')
    wei_f1 = f1_score(y, pred_label, average='weighted')
    return c_error,top_precision,top_loss,avg_pre,ham_loss,acc,macro_pre,micro_pre,weight_pre,mac_recall,mic_recall,wei_recall,mac_f1,mic_f1,wei_f1

def metrics_report(model,dataloader,target_names):#整体的y和pre
    #target_names是类别名称
    #这里的pred是0、1的类别one-hot值
    model.eval()
    with torch.no_grad():
        for X, y in dataloader:
            pred = model(X)
            pred=pred.sigmoid()
            print(classification_report(y_true=y, y_pred=pred, labels=target_names))

def getBinaryTensor(inputTensor, boundary):
    one = torch.ones_like(inputTensor)
    zero = torch.zeros_like(inputTensor)
    return torch.where(inputTensor > boundary, one, zero)


if __name__ == '__main__':
    pass
