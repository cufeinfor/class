# !/usr/bin/env python
# -*- coding: UTF-8 -*-
'''
@Project ：ActiveLearningForHumanValue 
@File ：trainer.py
@IDE  ：PyCharm 
@Author ：AmandaQiao
@Date ：2022/9/26 14:40 
@Description:
'''
import torch
from tqdm.auto import tqdm

from classifier.metrics import metrics
from classifier.multi_laber_classifier import classifer_model
from sklearn.metrics import coverage_error, label_ranking_average_precision_score, label_ranking_loss, \
    average_precision_score, accuracy_score, precision_score, recall_score, f1_score


# 定义训练，参数为：(数据、模型、loss函数、优化器、学习率(根据步数下降），epoch,记录整体loss)
def train_loop(dataloader, model, loss_fn, optimizer, lr_scheduler, epoch, total_loss):
    # 训练进度条
    progress_bar = tqdm(range(len(dataloader)))
    progress_bar.set_description(f'loss: {0:>7f}')
    finish_batch_num = (epoch - 1) * len(dataloader)
    model.train()
    for batch, (index,X, y) in enumerate(dataloader, start=1):  # 开始批量的读数据，一次一个batch
        pred = model(X)  # 使用模型进行训练,
        '''
        logits=classifer_model(X)
        pred=logits.sigmoid()
        '''
        # pred=pred.sigmoid()
        loss = loss_fn(pred, y.float())  # 使用loss function计算loss,pred是float类型，label是int型，所有要转换成float类型
        optimizer.zero_grad()  # 梯度清零
        loss.backward()  # loss梯度下降
        optimizer.step()  # 使用优化器更改参数
        lr_scheduler.step()  # 调整学习率
        total_loss += loss.item()  # 统计本批数据的loss
        # avg_loss=total_loss/finish_batch_num
        # 打印进度条数据，更新进度条
        progress_bar.set_description(f'loss: {total_loss / (finish_batch_num + batch):>7f}')
        progress_bar.update(1)
    return total_loss

#做测试
def test_loop(dataloader, model, mode='Test'):
    assert mode in ['Valid', 'Test']
    size = len(dataloader.dataset)
    error=0
    rank_precision=0
    rank_loss=0
    average_precision=0
    hamm_loss=0
    acc_score=0
    macro_precision=0
    micro_precsion=0
    weight_presion=0
    macro_recall=0
    micro_recall=0
    weight_recall=0
    macro_f1=0
    micro_f1=0
    weight_f1=0

    model.eval()
    i=0
    with torch.no_grad():
        for index,X, y in dataloader:
            pred = model(X)
            #调用metric获取指标
            c_error, top_precision, top_loss, avg_pre, ham_loss,acc, macro_pre, micro_pre, weight_pre, mac_recall, mic_recall, wei_recall, mac_f1, mic_f1, wei_f1=metrics(y,pred)
            error+=c_error
            rank_precision+=top_precision
            rank_loss+=top_loss
            average_precision += avg_pre
            hamm_loss+=ham_loss
            acc_score+=acc
            macro_precision+=macro_pre
            micro_precsion+=micro_pre
            weight_presion+=weight_pre
            macro_recall+=mac_recall
            micro_recall+=mic_recall
            weight_recall+=wei_recall
            macro_f1+=mac_f1
            micro_f1+=mic_f1
            weight_f1+=wei_f1
            i+=1

    error /= i#计算整体的覆盖误差
    rank_precision/=i
    rank_loss/=i
    average_precision/=i
    hamm_loss/=i
    acc_score/=i
    macro_precision/=i
    micro_precsion/=i
    weight_presion/=i
    macro_recall/=i
    micro_recall/=i
    weight_recall/=i
    macro_f1/=i
    micro_f1/=i
    weight_f1/=i

    print(f"{mode} coverage_error: {error}")
    print(f"{mode} rank_precision: {(100 * rank_precision):>0.1f}%")
    print(f"{mode} rank_loss: {rank_loss}")
    print(f"{mode} average_precision: {(100 * average_precision):>0.1f}%")
    print(f"{mode} hamm_loss: {(100 * hamm_loss):>0.1f}%")
    print(f"{mode} acc_score: {(100 * acc_score):>0.1f}%")
    print(f"{mode} macro_precision: {(100 * macro_precision):>0.1f}%")
    print(f"{mode} micro_precsion: {(100 * micro_precsion):>0.1f}%")
    print(f"{mode} weight_presion: {(100 * weight_presion):>0.1f}%")
    print(f"{mode} macro_recall: {(100 * macro_recall):>0.1f}%")
    print(f"{mode} micro_recall: {(100 * micro_recall):>0.1f}%")
    print(f"{mode} weight_recall: {(100 * weight_recall):>0.1f}%")
    print(f"{mode} macro_f1: {(100 * macro_f1):>0.1f}%")
    print(f"{mode} micro_f1: {(100 * micro_f1):>0.1f}%")
    print(f"{mode} weight_f1: {(100 * weight_f1):>0.1f}%")

    return error,rank_precision,rank_loss,average_precision,hamm_loss,acc_score,macro_precision,micro_precsion,weight_presion,macro_recall,micro_recall,weight_recall,macro_f1,micro_f1,weight_f1

def getBinaryTensor(inputTensor,boundary):
    one=torch.ones_like(inputTensor)
    zero=torch.zeros_like(inputTensor)
    return torch.where(inputTensor>boundary,one,zero)