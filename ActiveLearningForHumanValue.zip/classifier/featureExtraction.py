# !/usr/bin/env python
# -*- coding: UTF-8 -*-
'''
@Project ：ActiveLearningForHumanValue 
@File ：featureExtraction.py
@IDE  ：PyCharm 
@Author ：AmandaQiao
@Date ：2023/3/24 21:23 
@Description:
'''
import numpy as np
import pandas as pd
from sklearn.preprocessing import StandardScaler
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.multiclass import OneVsRestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import classification_report,coverage_error,label_ranking_average_precision_score,label_ranking_loss

from sklearn.svm import SVC
from sklearn.model_selection import learning_curve, validation_curve
import matplotlib.pyplot as plt
from sklearn.decomposition import PCA
from sklearn.cross_decomposition import CCA


def textFeatureExtraction(data):
    # 对空文本进行处理
    df['text'].fillna('default_value', inplace=True)
    # 特征提取：文本特征
    tfidf = TfidfVectorizer(max_features=5000)
    text_feature = tfidf.fit_transform(df['text']).toarray()
    return text_feature


def dataStandardization(dataPath,keys,savePath):
    '''
    :param data: 传入的数据
    :return: 标准化后的数据
    '''

    df = pd.read_csv(dataPath, encoding='utf-8')  # 读取数据

    # 实例化标准化器对象
    scaler = StandardScaler()#实例化
    #对数字特征进行标准化
    df1=df[keys]#取出需要标准化的数据
    #标准化方法1
    # standard_data=scaler.fit_transform(df1[keys])#标准化
    # for i in range(len(keys)):
    #     df1[keys[i]]=standard_data[:,i]
    # 标准化方法2，结果是一样的
    for i in range(len(keys)):
        df1[keys[i]]=scaler.fit_transform(df1[keys[i]].values.reshape(-1,1))#

    df=df.drop(keys,axis=1)#删除原来的数据
    data=pd.concat([df,df1],axis=1)#将标准化后的数据与原来的数据合并
    data.to_csv(savePath,index=False,encoding='utf-8')#保存数据
    return data#返回数据

if __name__ == '__main__':
    datapath='../jy/summary_valueSentiment.csv'
    # savepath='../jy/summary_valueSentiment_standard.csv'
    df=pd.read_csv(datapath,encoding='utf-8')
    keylist=df.columns[13:]
    # dataStandardization(datapath,keylist,savepath)
    # 对空文本进行处理
    # df['text'].fillna('default_value', inplace=True)
    df = df.dropna()
    # 特征提取：文本特征
    tfidf = TfidfVectorizer(max_features=5000)
    text_feature = tfidf.fit_transform(df['text']).toarray()

    # 特征提取：数字特征
    scaler = StandardScaler()
    numeric_features = scaler.fit_transform(df[keylist])

    # 合并特征
    features = np.concatenate([text_feature, numeric_features], axis=1)

    # 标签处理
    labelKey = df.columns[2:13]
    labels = pd.get_dummies(df[labelKey])

    # 划分训练集和测试集
    train_size = int(len(df) * 0.8)
    x_train, x_test = features[:train_size], features[train_size:]
    y_train, y_test = labels[:train_size], labels[train_size:]

    # 模型训练
    # clf = OneVsRestClassifier(LogisticRegression())
    clf=OneVsRestClassifier(SVC(kernel='linear'))
    clf.fit(x_train, y_train)
    # 模型预测
    y_pred = clf.predict(x_test)

    # 模型评估
    print(classification_report(y_test, y_pred))
    coverageError = coverage_error(y_test, y_pred)
    rankAvgScore=label_ranking_average_precision_score(y_test, y_pred)
    rankLoss=label_ranking_loss(y_test, y_pred)

    print('coverageError:',coverageError)
    print('rankAvgScore:',rankAvgScore)
    print('rankLoss:',rankLoss)



    # # 绘制学习曲线
    # train_sizes, train_scores, test_scores = learning_curve(estimator=clf,
    #                                                         X=x_train,
    #                                                         y=y_train,
    #                                                         train_sizes=np.linspace(0.1, 1.0, 10),
    #                                                         cv=5,
    #                                                         scoring='f1_micro',
    #                                                         n_jobs=-1)
    # train_scores_mean = np.mean(train_scores, axis=1)
    # test_scores_mean = np.mean(test_scores, axis=1)
    # plt.plot(train_sizes, train_scores_mean, 'o-', label='Training score')
    # plt.plot(train_sizes, test_scores_mean, 'o-', label='Cross-validation score')
    # plt.xlabel('Training examples')
    # plt.ylabel('F1 score')
    # plt.title('Learning Curve')
    # plt.legend(loc='best')
    # plt.show()
    #
    # # 绘制验证曲线
    # param_range = np.linspace(0.01, 1.0, 20)
    # train_scores, test_scores = validation_curve(estimator=clf,
    #                                              X=x_train,
    #                                              y=y_train,
    #                                              param_name='estimator__C',
    #                                              param_range=param_range,
    #                                              cv=5,
    #                                              scoring='f1_micro',
    #                                              n_jobs=-1)
    # train_scores_mean = np.mean(train_scores, axis=1)
    # test_scores_mean = np.mean(test_scores, axis=1)
    # plt.plot(param_range, train_scores_mean, 'o-', label='Training score')
    # plt.plot(param_range, test_scores_mean, 'o-', label='Cross-validation score')
    # plt.xlabel('Parameter C')
    # plt.ylabel('F1 score')
    # plt.title('Validation Curve')
    # plt.legend(loc='best')
    # plt.show()
