
from pathlib import Path
# BASE_DIR = Path('ActiveLearningForHumanValue')
config = {
    'raw_data_path':'dataset/train_sample.csv',
    'test_path': 'dataset/val.csv',

    'data_dir': 'dataset',
    'log_dir': 'output/log',
    'writer_dir': "output/TSboard",
    'figure_dir': "output/figure",
    'checkpoint_dir': "output/checkpoints/bert",
    'cache_dir': 'model/',
    'result': "output/result",

    'bert_vocab_path': 'bert/base-uncased/bert_vocab.txt',
    'bert_config_file':  'bert/base-uncased/config.json',
    'bert_model_dir':  'bert/base-uncased',

    'xlnet_vocab_path':  'xlnet/base-cased/spiece.model',
    'xlnet_config_file':  'xlnet/base-cased/config.json',
    'xlnet_model_dir': 'xlnet/base-cased',

    'albert_vocab_path': 'albert/albert-base/30k-clean.model',
    'albert_config_file': 'albert/albert-base/config.json',
    'albert_model_dir': 'albert/albert-base'


}

