# !/usr/bin/env python
# -*- coding: UTF-8 -*-
'''
@Project ：ActiveLearningForHumanValue 
@File ：active_learner.py
@IDE  ：PyCharm 
@Author ：Amanda
@Description:
'''
import os
import re
import warnings
import datetime
import pandas as pd
import torch
from torch import nn
from torch.utils.data import DataLoader
from tqdm import tqdm
from classifier.collote_data import collote_fn
from classifier.trainer import train_loop, test_loop
from transformers import AdamW, get_scheduler
import  wandb
wandb.login(key='')
wandb.init(project='my-active-learning-debug1031')

al_now_time = datetime.datetime.now()
al_temp_str = datetime.datetime.strftime(al_now_time, '%Y-%m-%d %H:%M:%S')
al_strs = re.sub(r"""[-|:| ]""", "_", al_temp_str)
al_base_path = f'learner/before_active_learning/checkpoint/'
al_log_path = al_base_path + al_strs
os.makedirs(al_log_path)

now_time = datetime.datetime.now()
temp_str = datetime.datetime.strftime(now_time, '%Y-%m-%d %H:%M:%S')
strs = re.sub(r"""[-|:| ]""", "_", temp_str)
base_path = f'learner/pre_train/'
temp_path = base_path + strs 
metric_path = temp_path + '/metric'
model_path = temp_path + '/model'
os.makedirs(metric_path)
os.makedirs(model_path)



loss_fn = nn.BCEWithLogitsLoss()  
#
# epoch_num=1000
# learning_rate = 1e-5  # 学习率

class MyActiveLearner():


    total_loss = 0.

    # best_error = 0.  
    # best_loss = 0.
    # best_rank_pre = 0. 
    # best_avg_pre = 0. 


    def __init__(self, estimator, query_strategy, train_dataloader, val_dataloader, data_pool,metrics):
        self.estimator=estimator
        self.query_strategy = query_strategy
        self.train_dataloader=train_dataloader
        self.data_pool=data_pool
        self.val_dataloader=val_dataloader
        # self.optimizer=optimizer
        # self.lr_scheduler=lr_scheduler
        self.metrics=metrics

        assert callable(query_strategy), 'query_strategy must be callable'



    def learner_query(self,n_instances):
        query_result = self.query_strategy(self.estimator,self.data_pool,n_instances)
        if isinstance(query_result, tuple):
            warnings.warn("Query strategies should no longer return the selected instances, "
                          "this is now handled by the query method. "
                          "Please return only the indices of the selected instances.", DeprecationWarning)
            return query_result
        sample=retrieve_rows(self.data_pool, query_result)#id对应的样本
        return query_result, sample

    def update_data(self,query_result, records):
        # Adds X and y to the known training data and retrains the predictor with the augmented dataset.
        train_dict = self.train_dataloader.dataset  
        lenth = len(train_dict.keys())
        for record in records:
            train_dict[lenth] = record
            lenth += 1
        self.train_dataloader = DataLoader(train_dict, collate_fn=collote_fn)

        temp_pool_dict = self.data_pool.dataset
        temp_pool = list(temp_pool_dict.values())  
        sort_query_result = sorted(query_result, reverse=True)  
        for i in sort_query_result:
            del temp_pool[i]
        datapool_df = pd.DataFrame(temp_pool)
        datapool_df_dict = datapool_df.to_dict(orient='index')
        update_data_pool = DataLoader(datapool_df_dict, collate_fn=collote_fn)  # 转换类型
        self.data_pool = update_data_pool

    def my_teach(self,query_result,records,epoch_num):


        # Adds X and y to the known training data and retrains the predictor with the augmented dataset.
        train_dict = self.train_dataloader.dataset 
        lenth = len(train_dict.keys())
        for record in records:
            train_dict[lenth] = record
            lenth += 1
        self.train_dataloader = DataLoader(train_dict, collate_fn=collote_fn)

        temp_pool_dict = self.data_pool.dataset
        temp_pool = list(temp_pool_dict.values())  
        sort_query_result = sorted(query_result, reverse=True)  
        for i in sort_query_result:
            del temp_pool[i]
        datapool_df = pd.DataFrame(temp_pool)
        datapool_df_dict = datapool_df.to_dict(orient='index')
        update_data_pool = DataLoader(datapool_df_dict, collate_fn=collote_fn)  # 转换类型
        self.data_pool = update_data_pool

        # current_train_dict = {} 
        # for i in range(len(records)):
        #     current_train_dict[i] = records[i]
        # current_train_dataloader = DataLoader(current_train_dict, collate_fn=collote_fn)#当前的训练数据

        epoch_data = []
        train_loss_data = []
        error_data = []
        rank_precision_data = []
        rank_loss_data = []
        average_precision_data = []
        ham_loss_data = []
        acc_score_data = []
        macro_precision_data = []
        micro_precsion_data = []
        weight_presion_data = []
        macro_recall_data = []
        micro_recall_data = []
        weight_recall_data = []
        macro_f1_data = []
        micro_f1_data = []
        weight_f1_data = []
        # end_epoch = start_epoch + epoch_num


        learning_rate = 1e-5  # 学习率
        optimizer = AdamW(self.estimator.parameters(), lr=learning_rate)  
        lr_scheduler = get_scheduler(
            "linear",  
            optimizer=optimizer,
            num_warmup_steps=0,
            num_training_steps=epoch_num * len(self.train_dataloader),
        )

        wandb.config = {
            "learning_rate": optimizer.state_dict()['param_groups'][0]['lr'],
            "epochs": epoch_num,
            "batch_size": 1
        }

        # metric_file = strs+'_'+'epoch_'+str(start_epoch)+'_'+str(end_epoch)+f'metrics.csv'
        metric_file = strs + f'_metrics.csv'
        metric_path_current = metric_path + '/' + metric_file 

        for t in range(epoch_num):
            print(f"Epoch {t + 1}/{epoch_num}\n-------------------------------")
            # print("learning rate:{}".format(self.optimizer.state_dict()['param_groups'][0]['lr']))

            MyActiveLearner.total_loss = train_loop(self.train_dataloader, self.estimator, loss_fn, optimizer, lr_scheduler,
                                      epoch_num, MyActiveLearner.total_loss)
error,rank_precision,rank_loss,average_precision,ham_loss,acc_score,macro_precision,micro_precsion,weight_presion,macro_recall,micro_recall,weight_recall,macro_f1,micro_f1,weight_f1 = test_loop(
                self.val_dataloader, self.estimator, mode='Valid')

            wandb.log({"error": error})
            wandb.log({"rank_precision": rank_precision})
            wandb.log({"rank_loss": rank_loss})
            wandb.log({"average_precision": average_precision})
            wandb.log({"ham_loss": ham_loss})
            wandb.log({"acc_score": acc_score})
            wandb.log({"macro_precision": macro_precision})
            wandb.log({"micro_precsion": micro_precsion})
            wandb.log({"weight_presion": weight_presion})
            wandb.log({"macro_recall": macro_recall})
            wandb.log({"micro_recall": micro_recall})
            wandb.log({"weight_recall": weight_recall})
            wandb.log({"macro_f1": macro_f1})
            wandb.log({"micro_f1": micro_f1})
            wandb.log({"weight_f1": weight_f1})

            # Optional
            wandb.watch(self.estimator)
            epoch_data.append(t)
            train_loss_data.append(MyActiveLearner.total_loss)
            error_data.append(error)
            rank_precision_data.append(rank_precision)
            rank_loss_data.append(rank_loss)
            average_precision_data.append(average_precision)
            ham_loss_data.append(ham_loss)
            acc_score_data.append(acc_score)
            macro_precision_data.append(macro_precision)
            micro_precsion_data.append(micro_precsion)
            weight_presion_data.append(weight_presion)
            macro_recall_data.append(macro_recall)
            micro_recall_data.append(micro_recall)
            weight_recall_data.append(weight_recall)
            macro_f1_data.append(macro_f1)
            micro_f1_data.append(micro_f1)
            weight_f1_data.append(weight_f1)


            if self.metrics['best_error']> error and rank_precision> self.metrics['best_rank_pre'] and self.metrics['best_loss']>rank_loss and average_precision > self.metrics['best_avg_pre']:
            # if MyActiveLearner.best_error> error and rank_precision> MyActiveLearner.best_rank_pre and MyActiveLearner.best_loss>rank_loss and average_precision > MyActiveLearner.best_avg_pre:
                self.metrics['best_error']=error
                self.metrics['best_rank_pre'] = rank_precision
                self.metrics['best_loss'] = rank_loss
                self.metrics['best_avg_pre'] = average_precision
                print('saving new weights...\n')
                file = f'epoch_{t + 1}_valid_error_{error:0.1f}_loss_{rank_loss:0.1f}_rpre_{(100 * rank_precision):0.1f}_avgpre_{(100 * average_precision):0.1f}_model_weights.bin'
                checkpoint = {
                    'epoch': t,
                    'estimator': self.estimator.state_dict(),
                    'optimizer': optimizer.state_dict(),
                    'lr_schedule': lr_scheduler.state_dict()}
                check_path=al_log_path + '/'+file
                torch.save(checkpoint, check_path)

                state_checkpoint=torch.load(check_path)
                model_state=state_checkpoint['estimator']
                optimizer_state=state_checkpoint['optimizer']
                lr_state=state_checkpoint['lr_schedule']
                # start_epoch=state_checkpoint['epoch']
                self.estimator.load_state_dict(model_state)
                # self.optimizer.load_state_dict(optimizer_state)
                # self.lr_scheduler.load_state_dict(lr_state)


            elif average_precision > self.metrics['best_avg_pre']:
                self.metrics['best_avg_pre'] = average_precision
                print('saving new weights...\n')
                file= f'epoch_{t + 1}_valid_avgpre_{(100 * average_precision):0.1f}_model_weights.bin'
                # path = model_path + '/' + file
                # torch.save(self.estimator.state_dict(), path)
                checkpoint = {
                    'epoch':t,
                    'estimator': self.estimator.state_dict(),
                    'optimizer': optimizer.state_dict(),
                    'lr_schedule': lr_scheduler.state_dict()}
                check_path = al_log_path + '/' + file
                torch.save(checkpoint, check_path)

                state_checkpoint = torch.load(check_path)
                model_state = state_checkpoint['estimator'] 
                optimizer_state = state_checkpoint['optimizer'] 
                lr_state = state_checkpoint['lr_schedule']
                # start_epoch=state_checkpoint['epoch']
                self.estimator.load_state_dict(model_state)
                # self.optimizer.load_state_dict(optimizer_state)
                # self.lr_scheduler.load_state_dict(lr_state)

        data = pd.DataFrame({'epoch': epoch_data, 'train_loss':train_loss_data,'coverage_error': error_data,'rank_precision': rank_precision_data,'rank_loss': rank_loss_data,'average_precision': average_precision_data, 'ham_loss': ham_loss_data, 'acc_score': acc_score_data,'macro_precision': macro_precision_data, 'micro_precsion': micro_precsion_data,'weight_presion': weight_presion_data,'macro_recall': macro_recall_data, 'micro_recall': micro_recall_data, 'weight_recall': weight_recall_data,'macro_f1': macro_f1_data, 'micro_f1': micro_f1_data, 'weight_f1': weight_f1_data})
        data.to_csv(metric_path_current)






    def predict(self,query_result):
        # pred_list=[]
        sample=[]
        for i in query_result:
            x=self.data_pool.dataset[i]
            sample.append(x)
        sample_dataloader=DataLoader(sample,collate_fn=collote_fn)

        pred_list=[]
        # for i in query_result:
        with torch.no_grad():
            for index,X,y in tqdm(sample_dataloader):
            # for X, y in dataloader:
                logits = self.estimator(X)
                probs = logits.sigmoid()
                probs=probs.detach().numpy().tolist()
                pred_list.append(probs)
        return pred_list


def retrieve_rows(Dataloader,index_list) :
    data=Dataloader.dataset
    result=[]
    for i in index_list:
        result.append(data[i])
    return result

def getBinaryTensor(inputTensor, boundary):
    one = torch.ones_like(inputTensor)
    zero = torch.zeros_like(inputTensor)
    return torch.where(inputTensor > boundary, one, zero)
