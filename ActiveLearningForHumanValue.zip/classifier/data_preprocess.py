# !/usr/bin/env python
# -*- coding: UTF-8 -*-
'''
@Project ：ActiveLearningForHumanValue 
@File ：data_preprocess.py
@IDE  ：PyCharm 
@Author ：AmandaQiao
@Date ：2022/10/17 23:01 
@Description:
'''

import re
import numpy
import pandas as pd
import enchant
import langid
import demoji
import contractions
from nltk import sent_tokenize, RegexpTokenizer, pos_tag, word_tokenize, WordNetLemmatizer
import numpy as np
from tqdm import tqdm
from autocorrect import Speller
from string import punctuation as ep#去除英文标点
from zhon.hanzi import punctuation as zp#去除中文标点

with open('D:/PycharmWorkspace/ActiveLearningForHumanValue/classifier/stopwords.txt') as f:
    stopwords = set(f.read().split('\n'))

tokenizer = RegexpTokenizer(r'\w+')
correct = Speller()
lemma = WordNetLemmatizer()

#数据预处理，调用这个就可以了
def data_preprocess(origin_file,pre_file):#用这个，数据预处理用的，去停用词之类的
    print("data preprocess start!")
    data = pd.read_csv(origin_file)  # 读取数据
    tqdm.pandas(desc='preprocessing')
    data['text']=data['text'].progress_apply(lambda x:sentencePreprocess(x))
    data.to_csv(pre_file, index=False)  # 存储到本地csv
    print("data preprocess done!")

def data_preprocess_first(origin_file,pre_file):#用这个，数据预处理用的，去停用词之类的
    print("data preprocess start!")
    data = pd.read_csv(origin_file)  # 读取数据
    tqdm.pandas(desc='preprocessing')
    data['text']=data['text'].progress_apply(lambda x:firstFilter(x))#得到纯文本长度/单词数大于3的数据，还没有去除数字这些内容
    # data.dropna(how='any',inplace=True)
    # data.dropna(subset=['text'],inplace=True)#删除text列中有空值的行
    data.to_csv(pre_file, index=False)  # 存储到本地csv
    print("data preprocess done!")

def data_preprocess_sencond(origin_file,pre_file):#用这个，数据预处理用的，去停用词之类的
    print("data preprocess start!")
    data = pd.read_csv(origin_file)  # 读取数据
    tqdm.pandas(desc='preprocessing')
    # data['text']=data['text'].progress_apply(lambda x:sentenceFilter(x))#得到去除数字\停用词之后的这些内容
    data['text'] = data['text'].progress_apply(lambda x: sentenceFilterContainStopwords(x))
    data.to_csv(pre_file, index=False)  # 存储到本地csv
    print("data preprocess done!")

def sentencePreprocess(content):
    '''
    :param content: 一条text,输入是sentence
    :return:去除非英文的评论，停用词、数字、以及评论里去掉表情,缩写扩展，
    '''
    #过滤长度小于3个词语的句子

    s1 = filter_str_nonEnglish(content)  # filter non-English
    s2=filter_text(s1)#过滤url,img,空格等
    if len(s2) != 0:
        s3 = demoji.replace(s2, "")  # filter emoj
        s0 = filter_punctuation(s3)  # 去除标点符号,基于此判断word是否大于3个词

        if len(re.split(' ',s0))>3:
            s4 = s0.lower()  # Convert to lowercase.
            s5 = contractions.fix(s4)  # 将词语缩写扩展词
            s6=correct.autocorrect_sentence(s5)#拼写检查
            s7 = tokenizer.tokenize(s6)  # Split into words.
            temp = []
            for word in s7:
                # word = filter_str_nonEnglish(word)#去除某些非英文的乱码字符,对单个单词的判断会有失误，经测验，乱码也能encoding，且数量不多，可以忽略
                if word!='':
                    if word not in stopwords:#去除停用词
                        if word.isnumeric() == False:#去除数字
                            temp.append(word)
            temp_sen=word_to_sentence(temp)
            if len(temp_sen)!=0:
                s8 = lemmatize(temp_sen)  # 词干提取
            else:
                s8=''
        else:
            s8=''
    else:
        s8=''
    return s8

def firstFilter(content):
    '''
    :param content:
    :return: 去除纯文本长度小于3个单词的review
    '''
    s1 = filter_str_nonEnglish(content)  # filter non-English
    s2 = filter_text(s1)  # 过滤url,img,空格等
    if len(s2) != 0:
        s3 = demoji.replace(s2, "")  # filter emoj
        s4 = filter_punctuation(s3)  # 去除标点符号,基于此判断word是否大于3个词

        if len(re.split(' ', s4)) > 3:
            return s4
        else:
            return ''

def sentenceFilter(content):
    '''
    :param content: 基于firstFilter过滤的句子，所以没有空值，也没有其他的，不需要再次判断,输入是sentence
    :return:去除非英文的评论，停用词、数字、以及评论里去掉表情,缩写扩展，
    '''
    #过滤长度小于3个词语的句子

    s4 = content.lower()  # Convert to lowercase.
    s5 = contractions.fix(s4)  # 将词语缩写扩展词
    s6=correct.autocorrect_sentence(s5)#拼写检查
    s7 = tokenizer.tokenize(s6)  # Split into words.
    temp = []
    for word in s7:
        if word!='':
            if word not in stopwords:#去除停用词
                if word.isnumeric() == False:#去除数字
                    temp.append(word)
    temp_sen=word_to_sentence(temp)
    if len(temp_sen)!=0:
        s8 = lemmatize(temp_sen)  # 词干提取
    else:
        s8=''

    return s8


def sentenceFilterContainStopwords(content):
    s4 = content.lower()  # Convert to lowercase.
    s5 = contractions.fix(s4)  # Expand contractions.
    s6 = correct.autocorrect_sentence(s5)  # Optional spelling correction.
    s7 = tokenizer.tokenize(s6)  # Split into words.

    # 保留原始词汇而不是去除停用词
    temp = [word for word in s7 if word.isalpha()]  # 只保留字母

    # 将单词合并回句子
    temp_sen = word_to_sentence(temp)
    return temp_sen if len(temp_sen) != 0 else ''




def sentences(content):
    '''
    :param content: review
    :return: 划分成句子的review,
    '''
    sentences = []
    for review in content:
        for txt in review:
            sentence = sent_tokenize(txt)
            for sen in sentence:
                if len(sen.split())>1:
                   sentences.append(sen)
    return sentences

def word_to_sentence(wordlist):
    '''
    :param wordlist:
    :return: 一句话
    '''
    senlist = []
    str = ''
    for word in wordlist:
        str += word + ' '
    if len(str.split())>1:
        senlist.append(str)

    if len(senlist)!=0:
        sentence=senlist[0]
    else:
        sentence=''
    return sentence

def lemmatize(sentence):#输入句子，输出句子
    tag=pos_tag(word_tokenize(sentence))
    result=[]
    for word, pos in tag:
        if pos.startswith('NN'):
            after= lemma.lemmatize(word,pos='n')
        elif pos.startswith('VB'):
            after= lemma.lemmatize(word,pos='v')
        elif pos.startswith('JJ'):
            after= lemma.lemmatize(word,pos='a')
        elif pos.startswith('R'):
            after= lemma.lemmatize(word, pos='r')
        else:
            after= word
        result.append(after)
    sen_after=word_to_sentence(result)
    return sen_after


def filter_str_nonEnglish(content):
    '''
    :param content: 待处理文本（一句话）
    :return: 如果是英文，则返回原文本，如果是非英文，则返回空
    '''
    if content == None or content == '':
        return ''
    elif type(content) == float:
        if np.isnan(content) == True:
            return ''
    else:
        lan = langid.classify(content)
        if lan[0] == 'en':
            return content
        else:
            return ''

def filter_text(text):#测验可以去除url,图片超链接
    re_tag = re.compile('</?\w+[^>]*>')  # HTML标签
    url_tag=re.compile(r'http[s]?://(?:[a-zA-Z]|[0-9]|[$-_@.&+]|[!*\(\),]|(?:%[0-9a-fA-F][0-9a-fA-F]))+')
    img_tag=re.compile(r'<img\salt.+/>')
    new_text = re.sub(re_tag, '', text)
    new_text=re.sub(url_tag,'',new_text)
    new_text = re.sub(img_tag, '', new_text)
    new_text = new_text.strip()  # 首尾去空格
    new_text = re.sub(",+", ",", new_text)   # 合并逗号
    new_text = re.sub(" +", " ", new_text)   # 合并空格
    new_text = re.sub("[...|…|。。。]+", "...", new_text)  # 合并句号
    new_text = re.sub("-+", "--", new_text)  # 合并-
    new_text = re.sub("———+", "———", new_text)  # 合并-
    return new_text

def filter_punctuation(content):
    '''
    :param content: 一句话
    :return: 去除中英文标点后的string
    '''
    s=''.join([c for c in content if c not in ep and c not in zp])
    return s

if __name__ == '__main__':
    train_path = '../dataset/active_learning_data/label_epoch/2024_10_01_20_50_17/train'
    print(0)
    add_train_path1 = train_path + '/current_train_after1.csv'
    currentTrainFilePath='../dataset/active_learning_data/label_epoch/2024_10_01_20_50_17/train/current_train.csv'
    data_preprocess_first(currentTrainFilePath, add_train_path1)  # 将本轮所有标注的数据进行预处理，作为待增加到base 训练集中的样本数据