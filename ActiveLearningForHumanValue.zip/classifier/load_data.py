# !/usr/bin/env python
# -*- coding: UTF-8 -*-
'''
@Project ：ActiveLearningForHumanValue 
@File ：Dataset.py
@IDE  ：PyCharm 
@Author ：AmandaQiao
@Date ：2022/9/26 10:07 
@Description:数据加载类
'''
import pandas as pd
# 模板代码

# import torch
from torch.utils.data import Dataset,DataLoader
# from tqdm import tqdm

# 定义数据处理类,方便后续模型读取批量数据。
# 继承Dataset类，来自定义自己的数据集加载方法，用于获取样本和标签，方便后续模型读取批量数据
class LoadData(Dataset):#自定义自己的Dataset类,主要实现init、len和item三个方法，其中init主要是读取数据，我们使用load_data来实现
#加载数据，不涉及数据预处理，把数据预处理放在加载数据前
    def __init__(self, path, data_type):
        self.data = self.load_data(path, data_type)

        # 核心实现，参数可以加data_type用于区分
    def load_data(self, path, data_type):  # 在不同下游任务中，主要修改这个数据加载函数即可
        file_path=path+data_type+'.csv'#要读取的文件路径
        data=pd.read_csv(file_path)#读取数据
        data_temp = data.drop(columns=['id','text'],inplace=False)
        data_temp=data_temp.values.tolist()
        data['label']=data_temp
        data=data[['id','text','label']].copy(deep=True)
        data.columns=['id','text','label']
        Data=data.to_dict(orient='index')
        return Data

    # 返回长度便于批量加载的时候计算数据量
    def __len__(self):
        return len(self.data)

    # 根据index可以去分数据是从[idx,idx]
    def __getitem__(self, idx):
        return self.data[idx]


    # def load_datas(self, path, data_type):  # 在不同下游任务中，主要修改这个数据加载函数即可
    #     file_path = path + data_type + '.csv'  # 要读取的文件路径
    #     data = pd.read_csv(file_path)  # 读取数据
    #     id = data['id'].tolist()
    #     sample = data['text'].tolist()  # 获取样本，是纯文本
    #     label = []  # 获取标签，[label1，label2.....]
    #     Achievement = data['Achievement'].tolist()
    #     Self_direction = data['Self-direction'].tolist()
    #     Hedonism = data['Hedonism'].tolist()
    #     Security = data['Security'].tolist()
    #     Power = data['Power'].tolist()
    #     Stimulation = data['Stimulation'].tolist()
    #     Benevolence = data['Benevolence'].tolist()
    #     Universalism = data['Universalism'].tolist()
    #     Conformity = data['Conformity'].tolist()
    #     Tradition = data['Tradition'].tolist()
    #     other = data['other'].tolist()
    #     for i in range(len(Achievement)):
    #         tmp = []
    #         tmp.append(Achievement[i])
    #         tmp.append(Self_direction[i])
    #         tmp.append(Hedonism[i])
    #         tmp.append(Security[i])
    #         tmp.append(Power[i])
    #         tmp.append(Stimulation[i])
    #         tmp.append(Benevolence[i])
    #         tmp.append(Universalism[i])
    #         tmp.append(Conformity[i])
    #         tmp.append(Tradition[i])
    #         tmp.append(other[i])
    #         label.append(tmp)
    #     Data = {}
    #     for idx in range(len(sample)):  # 字典类型，读取数据
    #         line = {'id': id[idx], 'text': sample[idx], 'label': label[idx]}  # 定义一条数据样本
    #         Data[idx] = line  # # 比如这个是第idx个数据，字典类型，包括数据样本和标签，赋值给Data
    #     return Data