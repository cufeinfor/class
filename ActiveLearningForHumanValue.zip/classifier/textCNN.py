# !/usr/bin/env python
# -*- coding: UTF-8 -*-
'''
@Project ：ActiveLearningForHumanValue 
@File ：textCNN.py
@IDE  ：PyCharm 
@Author ：AmandaQiao
@Date ：2023/3/26 20:13 
@Description:我的数据格式是个CSV，一列是text的id，一列是text，11列是类别标签（0是不属于该类别，1属于该类别），11类是这11类的概率值，1列是文本的情感得分，我应该怎么基于这个数据格式，用textCNN实现文本的多标签分类呢
我用bert进行了多标签分类，但是因为我的样本数量不均衡，我数据读取是用了pytorch的Dataloader，希望能够解决一下这个问题，可以帮我实现代码吗

我用bert进行了多标签分类，但是效果只有50%，可能是因为我的样本数量不均衡，我数据读取是用了pytorch的Dataloader，希望能够解决一下这个问题，可以帮我实现代码吗

我用bert进行了多标签分类，但是效果只有50%，可能是因为我的样本数量不均衡，我数据读取是用了pytorch的Dataloader，我想用smote方法解决这个问题，有没有可参考代码

我实现了一个图网络，基于不同关系提取的特征，经过attention聚合，怎么对这些关系进行权重调整呢

我定义了GAT网络，基于github中issue-issue文本相似关系、issue-developer交互关系，developer-developer之间的协作关系，我想基于这三种关系进行特征聚合，最后用户issue的开发者推荐，这三种关系的权重应该如何学习并设置呢
'''


def fun1(a, b):
    '''
   :@para a:
   :@para b:
   :return:
   '''


if __name__ == '__main__':
    pass
